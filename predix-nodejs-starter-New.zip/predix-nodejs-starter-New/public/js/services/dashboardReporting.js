'use strict';

app.factory('dashboardReporting', ['$q', '$http','$timeout','$rootScope','$cookies','$cookieStore','constants', 'toaster', '$filter',
	function ($q, $http,$timeout, $rootScope,$cookies,$cookieStore,constants, toaster, $filter) {
	    var cookie = $cookieStore.get("sc_token");
		var refreshCookie = $cookieStore.get("sc_refresh_token");
		$cookieStore.put("companyAddress", []);
		var dashboardReporting = {
			getCookieVal:function(){
				return $cookieStore.get("sc_token");
			},
			
			getOverAllStatus:function(){
		    	var url = constants.GET_REQUEST_OVERALL_STATUS;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dashboardReporting.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;

			},

			getApprovingStatus:function(){
		    	var url = constants.GET_REQUEST_APPROVING_STATUS;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dashboardReporting.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;
			},
			getInvitationStatus:function(){
		    	var url = constants.GET_REQUEST_INVITATION_STATUS;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dashboardReporting.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;
			},
			getTasksCompletion:function(){
		    	var url = constants.GET_TASKS_COMPLETION;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dashboardReporting.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;
			},
			getSelfServeCycleTime:function(){
		    	var url = constants.GET_SELF_SERVE_CYCLE_TIME;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dashboardReporting.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;
			},
			getComplianceAndPayments:function(){
				var url = constants.GET_COMPLIANCE_PAYMENTS;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dashboardReporting.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;

			}
			
		}
		return dashboardReporting;
	}
]);
