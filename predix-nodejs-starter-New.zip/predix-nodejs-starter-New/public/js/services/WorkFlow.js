'use strict';
app.factory('WorkFlow', ['Base64', '$q', '$http', '$rootScope', '$cookies', '$cookieStore', 'constants',
    function (Base64, $q, $http, $rootScope, $cookies, $cookieStore, constants) {
        $rootScope.startsWith = function (actual, expected) {
            var lowerStr = (actual + "").toLowerCase();
            return lowerStr.indexOf(expected.toLowerCase()) === 0;
        }

        //var baseUrl = 'https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/PC_WORKFLOW';	
        var authData = Base64.encode('supplier' + ':' + 'supplier123');
        var reviewData = {};
        //var instanceId = null;
        var taskId = "";
        var instanceId = "";
        var requestId = "";
        var newSubscribeRequestId = ""
        var favoriteCookie = $cookieStore.get("sc_token");
        var WorkFlow = {
            getCookieVal: function () {
                return $cookieStore.get("sc_token");
            },
            createInstance: function (requestObj) {
                /*baseUrl+'/runtime/process-instances'*/

                var url = constants.CREATE_INSTANCE;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: requestObj
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getNewSupplierReview: function (id) {
                var url = constants.SUPPLIER_REVIEW_REQUEST + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject(reply.data);
                });
                return d.promise;
            },
            setNewRequestId: function (id) {
                newSubscribeRequestId = id;
            },
            getSubscribeRequestId: function () {
                return newSubscribeRequestId;
            },
            getTaskId: function (id) {

                /*baseUrl+'/runtime/tasks?processInstanceId='+id*/

                var url = constants.GET_TASKID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                };
                console.log(req)
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            assignTask: function (id) {


                var obj = {
                    "assignee": $cookieStore.get("uId")
                            //"assignee":localStorage.getItem("uId")
                };
                /*baseUrl+'/runtime/tasks/'+id*/
                var url = constants.ASSIGN_TASK + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'PUT',
                    data: obj

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            prepareVariables: function (model, pageInfo) {
                reviewData[pageInfo] = model;
                console.log(reviewData);
                var exclude_array = ['dba_name',
                    'country_incorporation',
                    'vat_type', 'vat_id']
                var obj = [];
                angular.forEach(model, function (value, key) {
                    if ($.inArray(key, exclude_array) == -1) {
                        obj.push({
                            name: key,
                            value: value
                        });
                    }
                });
                return obj;
            },
            setVariables: function (obj, id) {
                /*baseUrl+'/runtime/process-instances/'+id+'/variables'*/

                var url = constants.SET_VARIABLES + id + '/variables';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'PUT',
                    data: obj

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            completeTask: function (id) {

                var obj = {
                    "action": "complete",
                    "variables": [
                    ]};
                /*baseUrl+'/runtime/tasks/'+id*/
                var url = constants.COMPLETE_TASK + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            cancelTask: function (id) {

                var obj = {
                    "action": "complete",
                    "variables": [{"name": "cancel", "value": "true"}
                    ]
                }
                /*baseUrl+'/runtime/tasks/'+id*/
                var url = constants.CANCEL_TASK + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getHistory: function (id) {
                /*baseUrl+'/history/historic-process-instances?processInstanceId='+id+'&includeProcessVariables=true'*/
                var url = constants.GET_HISTORY + id + '&includeProcessVariables=true';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getAvailableTask: function (id) {
                /*baseUrl+'/history/historic-process-instances?processInstanceId='+id+'&includeProcessVariables=true'*/
                var url = constants.NEW_AVAILABLE_TASK;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        //'Authorization' : 'Basic ' + authData
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            makeModel: function (obj) {

                var temp = {};
                angular.forEach(obj, function (value, key) {
                    temp[value.name] = value.value;
                });
                return temp;
            },
            getReviewData: function () {
                return reviewData;
            },
            setTask: function (id) {
                taskId = id;
                $cookieStore.put("taskId", id);
                //localStorage.setItem('taskId',id);
            },
            getTask: function () {
                taskId = $cookieStore.get("taskId");
                return taskId;
                //return localStorage.getItem('taskId');
            },
            setInstance: function (id) {
                instanceId = id;
                $cookieStore.put("instanceId", id);
                //localStorage.setItem('instanceId',id);
            },
            getInstance: function () {
                instanceId = $cookieStore.get("instanceId");
                return instanceId;
                //return localStorage.getItem('instanceId');
            },
            startInstanceV2: function () {
                var url = constants.START_INSTANCE;
                var data = {};
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'PUT',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            setVariablesV2: function (obj) {
                var url = constants.NEW_SET_VARIABLES + WorkFlow.getRequestId();
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            setVariablesV2Subscribe: function (obj) {
                var url = constants.NEW_SET_VARIABLES + $cookieStore.get("subscribeRequestId");
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getVariablesV2: function (obj) {
                var url = constants.NEW_SET_VARIABLES + WorkFlow.getRequestId();
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getVariablesV2Subscribe: function () {
                var url = constants.NEW_SET_VARIABLES + $cookieStore.get("subscribeRequestId");
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            cancelWorkflowV2: function (id) {
                var url = constants.CANCEL_WORKFLOW + id + '/cancel';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: {}

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            completeWorkflowV2: function () {
                var url = constants.COMPLETE_WORKFLOW + WorkFlow.getTask() + '/complete';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: {}

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            completeWorkflowForSearchTab: function (id) {
                var url = constants.COMPLETE_WORKFLOW + id + '/complete';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: {}


                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            completeWorkflowV2Subscribe: function () {
                var url = constants.COMPLETE_WORKFLOW + $cookieStore.get("subscribeTaskId") + '/complete';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: {}

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            completeWorkflowById: function (id) {
                debugger;
                var url = constants.COMPLETE_WORKFLOW + id + '/complete';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: {}

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getVRequestIdV2: function () {
                var url = constants.GET_REQUEST_ID + WorkFlow.getInstance() + '/variables';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            setRequestId: function (id) {
                requestId = id;
                $cookieStore.put("requestId", id);
                //localStorage.setItem('requestId',id);
            },
            getRequestId: function () {
                requestId = $cookieStore.get("requestId");
                return requestId;
                //return localStorage.getItem('requestId');
            },
            getVariablesById: function (id) {
                var url = constants.NEW_SET_VARIABLES + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            searchWorkflowSave: function (id, obj) {

                var url = constants.SEARCH_WF_SAVE + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': WorkFlow.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj

                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            }

        };
        return WorkFlow;
    }
]);
app.factory('Base64', function () {

    var keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    return {
        encode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;
            do {
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);
                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;
                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }

                output = output +
                        keyStr.charAt(enc1) +
                        keyStr.charAt(enc2) +
                        keyStr.charAt(enc3) +
                        keyStr.charAt(enc4);
                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";
            } while (i < input.length);
            return output;
        },
        decode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;
            // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
            var base64test = /[^A-Za-z0-9\+\/\=]/g;
            if (base64test.exec(input)) {
                window.alert("There were invalid base64 characters in the input text.\n" +
                        "Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
                        "Expect errors in decoding.");
            }
            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
            do {
                enc1 = keyStr.indexOf(input.charAt(i++));
                enc2 = keyStr.indexOf(input.charAt(i++));
                enc3 = keyStr.indexOf(input.charAt(i++));
                enc4 = keyStr.indexOf(input.charAt(i++));
                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;
                output = output + String.fromCharCode(chr1);
                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }

                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";
            } while (i < input.length);
            return output;
        }
    };
});
