
app.controller('headerController', function ($scope, $filter, $http, $rootScope, $state, $timeout, toaster, constants,
        $cookies, $cookieStore, $location, WorkFlow, supplier) {
//	$('#delType').removeClass("invalid");
    // //Clear all data
    // //localStorage.clear();
    // $cookieStore.remove("instanceId");
    //    $cookieStore.remove("taskId");
    //    $cookieStore.remove("requestId");
    //   // $cookieStore.remove("uId");	
    //    $cookieStore.remove("commodityFamilyId");	
    //    $cookieStore.remove("email");	
    //    $cookieStore.remove("supplierName");	
    //    $cookieStore.remove("supplierFirstName");	
    //    $cookieStore.remove("supplierLastName");
    $('#myframe').contents().find('.rn_SearchArea').css({
        opacity: 0,
        color: 'red'
    });
    $('#myframe').contents().find('.rn_SearchArea').css('width', '100%');
    $('#myframe').contents().find('.rn_SearchArea').css('color', 'red');
    var cookie = $cookieStore.get("sc_token");
    /*https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/getprofile*/
    $scope.persona='';
    
    $scope.logout = function () {

        document.cookie = encodeURIComponent("sc_sso") + "=deleted; expires=" + new Date(0).toUTCString();
        document.cookie = encodeURIComponent("sc_token") + "=deleted; expires=" + new Date(0).toUTCString();

        var fullUrl = window.location.href;
        var extractUrl = fullUrl.split('//');
        var extractUrl1 = extractUrl[1];
        var extractUrl2 = extractUrl1.split('/')
        var finalUrl = extractUrl2[0] + "/logout";
        var logoutUrl = finalUrl;
        window.location.replace("https://" + finalUrl);
        //$("#logout").attr("href", logoutUrl); 
    }


    $scope.doSearch = function () {
        supplier.setSearchParams($scope.searchKey);
        $state.go('supplierSearch');
    }
    
   

    /*
     console.log($state.current);
     $scope.showInvitation = false;
     if($state.current.name =='homePage'){
     $scope.showInvitation = true;
     }*/


    /*
     $scope.inviteSupplier = function () {
     
     alert($scope.inviteEnabled)
     
     if($state.current.name!='homePage') {						
     return
     } 
     
     var workflowObj = {
     "processDefinitionKey":"SupplierConnectAddAndSubscribe",
     "businessKey":"myBusinessKey",
     "variables":[{"name": "mode", "value" : "ADD"}]
     }
     WorkFlow.createInstance(workflowObj).then(function(data){
     console.log(data);
     WorkFlow.getTaskId(data.id).then(function(data){
     console.log(data);
     WorkFlow.setTask(data.data[0].id);	
     WorkFlow.assignTask(data.data[0].id).then(function(data){
     console.log(data);
     WorkFlow.setInstance(data.processInstanceId);
     
     
     
     },function(data){});
     
     },function(data){});
     
     },function(data){});
     
     $state.go('supplierInfo');
     }
     
     
     Auth.getRoles().then(function(roles){
     $scope.inviteEnabled = Auth.isRoleExists(roles[0].authorities , 'ADD_SUPPLIER');
     console.log($scope.inviteEnabled)
     }, function() {
     toaster.pop('error', "Role list", "server not responding");
     }); */





});
