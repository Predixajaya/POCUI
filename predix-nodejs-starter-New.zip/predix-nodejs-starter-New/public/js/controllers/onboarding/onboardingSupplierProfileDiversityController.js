app.controller('onboardingSupplierProfileDiversityController', function($scope, $filter, $http, $rootScope,constants,
		$state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier) {
	$scope.loader=false;
	$scope.fileDownload=false;
	var cookie = $cookieStore.get("sc_token");
	$scope.supplierInfo={};
	$scope.supplierInfo.diversityCheckBox=false;
	if($scope.supplierInfo.diversityCheckBox==true){
		$scope.dateSection=true;
		$scope.uploadSection=true;	
	}

	if(!WorkFlow.getRequestId()){
		toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
		//$state.go('supplierHome');
		return;		
	}
	//WfModel.diversities = 
	$scope.diversity = '';
	$scope.diversities = {};
	var WfModel = {};
	WorkFlow.getVariablesV2().then(function(workflowData) {		
		WfModel = workflowData.data;
		$scope.showScore = false;
		if(WfModel.supplier.countryId == "10206"){
			$scope.showScore = true;
		}
		if(WfModel.supplier.certifications != null){
			if(WfModel.supplier.certifications.isMemberOfGovernmentSupplyChain == true){
				$scope.supplierInfo.isMemberOfGovernmentSupplyChain = WfModel.supplier.certifications.isMemberOfGovernmentSupplyChain;
				$scope.supplierInfo.governmentSupplyChainProgram = WfModel.supplier.certifications.governmentSupplyChainProgram;
				$scope.supplierInfo.governmentSupplyChainCertNumber = WfModel.supplier.certifications.governmentSupplyChainCertNumber;	
			}
			if(WfModel.supplier.certifications.hasAnyISOCertifications == true){
				$scope.supplierInfo.hasAnyISOCertifications = WfModel.supplier.certifications.hasAnyISOCertifications;
				$scope.supplierInfo.isoCertificationNumber = WfModel.supplier.certifications.isoCertificationNumber;
				$scope.supplierInfo.isoCertificationsCertDocId = WfModel.supplier.certifications.isoCertificationsCertDocId;
				$scope.fileDownload_isoCert=true;
            	var getId=document.getElementById('downloadUrlForFile_isoCert');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.certifications.isoCertificationsCertDocId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.isoCertificationsCertDocId).then(function(data) {
			  		$scope.fileNameIsoCert=data.FileName;
			  	}, function(data) {});	
			}
			if (WfModel.supplier.certifications.hasAnyOtherCertifications == true){
				$scope.supplierInfo.hasAnyOtherCertifications = WfModel.supplier.certifications.hasAnyOtherCertifications;
				$scope.supplierInfo.otherCertificationNumber = WfModel.supplier.certifications.otherCertificationNumber;
				$scope.supplierInfo.otherCertificationsCertDocId = WfModel.supplier.certifications.otherCertificationsCertDocId;
				$scope.fileDownload_otherCert=true;
            	var getId=document.getElementById('downloadUrlForFile_otherCert');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.certifications.otherCertificationsCertDocId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.otherCertificationsCertDocId).then(function(data) {
			  		$scope.fileNameOtherCert=data.FileName;
			  	}, function(data) {});	
			}
		}
		// get diversity data
		if(WfModel.supplier.diversity != null) {
			if(WfModel.supplier.diversity.alaskaNativeAndIndian.apply == true){
				$scope.supplierInfo.alaskaNativeAndIndian = WfModel.supplier.diversity.alaskaNativeAndIndian.apply;
				$scope.supplierInfo.alaskaNativeAndIndianCertId = WfModel.supplier.diversity.alaskaNativeAndIndian.certificateDocumentId;
				$scope.supplierInfo.alaskaNativeAndIndianCertificateExpirationDate = WfModel.supplier.diversity.alaskaNativeAndIndian.certificateExpirationDate;
				$scope.supplierInfo.alaskaNativeAndIndianScore = WfModel.supplier.diversity.alaskaNativeAndIndian.score;
				$scope.fileDownload_alaskaNativeAndIndianCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_alaskaNativeAndIndianCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.alaskaNativeAndIndian.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.alaskaNativeAndIndianCertId).then(function(data) {
			  		$scope.fileNameAlaskaNativeAndIndianCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.blackOwned.apply == true){
				$scope.supplierInfo.blackOwned = WfModel.supplier.diversity.blackOwned.apply;
				$scope.supplierInfo.blackOwnedCertId = WfModel.supplier.diversity.blackOwned.certificateDocumentId;
				$scope.supplierInfo.blackOwnedCertificateExpirationDate = WfModel.supplier.diversity.blackOwned.certificateExpirationDate;
				$scope.supplierInfo.blackOwnedScore = WfModel.supplier.diversity.blackOwned.score;
				$scope.fileDownload_blackOwnedCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_blackOwnedCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.blackOwned.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.blackOwnedCertId).then(function(data) {
			  		$scope.fileNameBlackOwnedCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.historicallyBlackColleges.apply == true){
				$scope.supplierInfo.historicallyBlackColleges = WfModel.supplier.diversity.historicallyBlackColleges.apply;
				$scope.supplierInfo.historicallyBlackCollegesCertId = WfModel.supplier.diversity.historicallyBlackColleges.certificateDocumentId;
				$scope.supplierInfo.historicallyBlackCollegesCertificateExpirationDate = WfModel.supplier.diversity.historicallyBlackColleges.certificateExpirationDate;
				$scope.supplierInfo.historicallyBlackCollegesScore = WfModel.supplier.diversity.historicallyBlackColleges.score;
				$scope.fileDownload_historicallyBlackCollegesCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_historicallyBlackCollegesCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.historicallyBlackColleges.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.historicallyBlackCollegesCertId).then(function(data) {
			  		$scope.fileNameHistoricallyBlackCollegesCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.historicallyUnderutilizedBusiness.apply == true){
				$scope.supplierInfo.historicallyUnderutilizedBusiness = WfModel.supplier.diversity.historicallyUnderutilizedBusiness.apply;
				$scope.supplierInfo.historicallyUnderutilizedBusinessCertId = WfModel.supplier.diversity.historicallyUnderutilizedBusiness.certificateDocumentId;
				$scope.supplierInfo.historicallyUnderutilizedBusinessCertificateExpirationDate = WfModel.supplier.diversity.historicallyUnderutilizedBusiness.certificateExpirationDate;
				$scope.supplierInfo.historicallyUnderutilizedBusinessScore = WfModel.supplier.diversity.historicallyUnderutilizedBusiness.score;
				$scope.fileDownload_historicallyUnderutilizedBusinessCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_historicallyUnderutilizedBusinessCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.historicallyUnderutilizedBusiness.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.historicallyUnderutilizedBusinessCertId).then(function(data) {
			  		$scope.fileNameHistoricallyUnderutilizedBusinessCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.lgbtBusiness.apply == true){
				$scope.supplierInfo.lgbtBusiness = WfModel.supplier.diversity.lgbtBusiness.apply;
				$scope.supplierInfo.lgbtBusinessCertId = WfModel.supplier.diversity.lgbtBusiness.certificateDocumentId;
				$scope.supplierInfo.lgbtBusinessCertificateExpirationDate = WfModel.supplier.diversity.lgbtBusiness.certificateExpirationDate;
				$scope.supplierInfo.lgbtBusinessScore = WfModel.supplier.diversity.lgbtBusiness.score;
				$scope.fileDownload_lgbtBusinessCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_lgbtBusinessCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.lgbtBusiness.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.lgbtBusinessCertId).then(function(data) {
			  		$scope.fileNameLgbtBusinessCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.minorityBusiness.apply == true){
				$scope.supplierInfo.minorityBusiness = WfModel.supplier.diversity.minorityBusiness.apply;
				$scope.supplierInfo.minorityBusinessCertId = WfModel.supplier.diversity.minorityBusiness.certificateDocumentId;
				$scope.supplierInfo.minorityBusinessCertificateExpirationDate = WfModel.supplier.diversity.minorityBusiness.certificateExpirationDate;
				$scope.supplierInfo.minorityBusinessScore = WfModel.supplier.diversity.minorityBusiness.score;
				$scope.fileDownload_minorityBusinessCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_minorityBusinessCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.minorityBusiness.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.minorityBusinessCertId).then(function(data) {
			  		$scope.fileNameMinorityBusinessCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.serviceDisabledVeteranSmallBusiness.apply == true){
				$scope.supplierInfo.serviceDisabledVeteranSmallBusiness = WfModel.supplier.diversity.serviceDisabledVeteranSmallBusiness.apply;
				$scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertId = WfModel.supplier.diversity.serviceDisabledVeteranSmallBusiness.certificateDocumentId;
				$scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertificateExpirationDate = WfModel.supplier.diversity.serviceDisabledVeteranSmallBusiness.certificateExpirationDate;
				$scope.supplierInfo.serviceDisabledVeteranSmallBusinessScore = WfModel.supplier.diversity.serviceDisabledVeteranSmallBusiness.score;
				$scope.fileDownload_serviceDisabledVeteranSmallBusinessCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_serviceDisabledVeteranSmallBusinessCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.serviceDisabledVeteranSmallBusiness.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertId).then(function(data) {
			  		$scope.fileNameServiceDisabledVeteranSmallBusinessCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.smallDisadvantagedBusiness.apply == true){
				$scope.supplierInfo.smallDisadvantagedBusiness = WfModel.supplier.diversity.smallDisadvantagedBusiness.apply;
				$scope.supplierInfo.smallDisadvantagedBusinessCertId = WfModel.supplier.diversity.smallDisadvantagedBusiness.certificateDocumentId;
				$scope.supplierInfo.smallDisadvantagedBusinessCertificateExpirationDate = WfModel.supplier.diversity.smallDisadvantagedBusiness.certificateExpirationDate;
				$scope.supplierInfo.smallDisadvantagedBusinessScore = WfModel.supplier.diversity.smallDisadvantagedBusiness.score;
				$scope.fileDownload_smallDisadvantagedBusinessCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_smallDisadvantagedBusinessCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.smallDisadvantagedBusiness.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.smallDisadvantagedBusinessCertId).then(function(data) {
			  		$scope.fileNameSmallDisadvantagedBusinessCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.veteranOwnedSmallBusiness.apply == true){
				$scope.supplierInfo.veteranOwnedSmallBusiness = WfModel.supplier.diversity.veteranOwnedSmallBusiness.apply;
				$scope.supplierInfo.veteranOwnedSmallBusinessCertId = WfModel.supplier.diversity.veteranOwnedSmallBusiness.certificateDocumentId;
				$scope.supplierInfo.veteranOwnedSmallBusinessCertificateExpirationDate = WfModel.supplier.diversity.veteranOwnedSmallBusiness.certificateExpirationDate;
				$scope.supplierInfo.veteranOwnedSmallBusinessScore = WfModel.supplier.diversity.veteranOwnedSmallBusiness.score;
				$scope.fileDownload_veteranOwnedSmallBusinessCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_veteranOwnedSmallBusinessCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.veteranOwnedSmallBusiness.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.veteranOwnedSmallBusinessCertId).then(function(data) {
			  		$scope.fileNameVeteranOwnedSmallBusinessCert=data.FileName;
			  	}, function(data) {});
			}
			if(WfModel.supplier.diversity.womenOwnedSmallBusiness.apply == true){
				$scope.supplierInfo.womenOwnedSmallBusiness = WfModel.supplier.diversity.womenOwnedSmallBusiness.apply;
				$scope.supplierInfo.womenOwnedSmallBusinessCertId = WfModel.supplier.diversity.womenOwnedSmallBusiness.certificateDocumentId;
				$scope.supplierInfo.womenOwnedSmallBusinessCertificateExpirationDate = WfModel.supplier.diversity.womenOwnedSmallBusiness.certificateExpirationDate;
				$scope.supplierInfo.womenOwnedSmallBusinessScore = WfModel.supplier.diversity.womenOwnedSmallBusiness.score;
				$scope.fileDownload_womenOwnedSmallBusinessCertId=true;
            	var getId=document.getElementById('downloadUrlForFile_womenOwnedSmallBusinessCertId');
            	getId.href= constants.FILE_DOWNLOAD+WfModel.supplier.diversity.womenOwnedSmallBusiness.certificateDocumentId;
			  	supplier.getlistFileUploaded($scope.supplierInfo.womenOwnedSmallBusinessCertId).then(function(data) {
			  		$scope.fileNameWomenOwnedSmallBusinessCert=data.FileName;
			  	}, function(data) {});
			}
		}

		//get diversity enabled data
		supplier.diversityRules(WfModel.requestId).then(function(data) {
			$scope.showDiversityInfoBlock = false;			
			$scope.diversities = data.data;
			angular.forEach($scope.diversities, function(value, key){
				if(value.enabled == true){
					$scope.showDiversityInfoBlock = true;
				}
			})
		}, function(data) {
			if(data == undefined){
				$scope.showDiversityInfoBlock = false;
			}
			toaster.pop('error', "Diversity Rule Engine!", "Server is not responding");
		});
		// supplier.diversityRules(WfModel.requestId).then(function(data) {				
		// 	$scope.diversities = data;
		// 	if(workflowData.data){
		// 		angular.forEach($scope.diversities.data, function(value1, key1) {
		// 			angular.forEach(WfModel.supplier.diversity, function(value2, key2) {
		// 				//debugger;						
		// 					if(value1.id==value2.id) {
		// 						$scope.showVisibityDiv = true;
		// 						value1.diversityCheckBox = value2.apply;
		// 						value1.uploadUrl = value2.certificateDocumentId;									
		// 						value1.fileDownload = (value2.certificateDocumentId)?true:false;
		// 						value1.score = value2.score;
		// 						$scope.diversityCheckFun(value1);
		// 					}else{
		// 						$scope.showVisibityDiv = false;
		// 					}
		// 			});	
		// 		});
		// 	}
				
		// }, function(data) {
		// });
	}, function(data) {
	});
	
	$scope.showComponent = function(type, fields) {
		var exists= ($filter('filter')(fields, {type:type}));		
		return exists.length;
	}

	$scope.prevForDiversityInfo=function(){
		$state.go('supplierProfileContacts');
	}

	$scope.diversityCheckFun=function(item){
		if(item.diversityCheckBox==true){
			item.dateSection=true;
			item.uploadSection=true;
			//item.mainCheck=true;
			//$scope.supplierInfo.diversityCheckBox=true;
		}
		else{
			item.dateSection=false;
			item.uploadSection=false;
			//item.mainCheck=false;
			//$scope.supplierInfo.diversityCheckBox=false;
		}
	}
	$scope.saveDiversity=function(supplierInfo,text){
		$scope.loader=true;
		
		//certifications 
		WfModel.supplier.certifications = {
			isMemberOfGovernmentSupplyChain: $scope.supplierInfo.isMemberOfGovernmentSupplyChain,
			governmentSupplyChainProgram: $scope.supplierInfo.governmentSupplyChainProgram,
			governmentSupplyChainCertNumber: $scope.supplierInfo.governmentSupplyChainCertNumber,
			 
			hasAnyISOCertifications: $scope.supplierInfo.hasAnyISOCertifications,
			isoCertificationNumber: $scope.supplierInfo.isoCertificationNumber,
			isoCertificationsCertDocId: $scope.supplierInfo.isoCertificationsCertDocId,
			 
			hasAnyOtherCertifications: $scope.supplierInfo.hasAnyOtherCertifications,
			otherCertificationNumber:$scope.supplierInfo.otherCertificationNumber,
			otherCertificationsCertDocId:$scope.supplierInfo.otherCertificationsCertDocId
		}

		//diversity
		WfModel.supplier.diversity = {
			alaskaNativeAndIndian: {
              	apply: $scope.supplierInfo.alaskaNativeAndIndian,
              	certificateDocumentId: $scope.supplierInfo.alaskaNativeAndIndianCertId,
              	certificateExpirationDate: $scope.supplierInfo.alaskaNativeAndIndianCertificateExpirationDate,
               	score: $scope.supplierInfo.alaskaNativeAndIndianScore
            },
            blackOwned: {
              	apply: $scope.supplierInfo.blackOwned,
              	certificateDocumentId: $scope.supplierInfo.blackOwnedCertId,
              	certificateExpirationDate: $scope.supplierInfo.blackOwnedCertificateExpirationDate,
               	score: $scope.supplierInfo.blackOwnedScore
            },
            historicallyBlackColleges: {
              	apply: $scope.supplierInfo.historicallyBlackColleges,
              	certificateDocumentId: $scope.supplierInfo.historicallyBlackCollegesCertId,
              	certificateExpirationDate: $scope.supplierInfo.historicallyBlackCollegesCertificateExpirationDate,
               	score: $scope.supplierInfo.historicallyBlackCollegesScore
            },
            historicallyUnderutilizedBusiness: {
              	apply: $scope.supplierInfo.historicallyUnderutilizedBusiness,
              	certificateDocumentId: $scope.supplierInfo.historicallyUnderutilizedBusinessCertId,
              	certificateExpirationDate: $scope.supplierInfo.historicallyUnderutilizedBusinessCertificateExpirationDate,
               	score: $scope.supplierInfo.historicallyUnderutilizedBusinessScore
            },
            lgbtBusiness: {
              	apply: $scope.supplierInfo.lgbtBusiness,
              	certificateDocumentId: $scope.supplierInfo.lgbtBusinessCertId,
              	certificateExpirationDate: $scope.supplierInfo.lgbtBusinessCertificateExpirationDate,
               	score: $scope.supplierInfo.lgbtBusinessScore
            },
            minorityBusiness: {
              	apply: $scope.supplierInfo.minorityBusiness,
              	certificateDocumentId: $scope.supplierInfo.minorityBusinessCertId,
              	certificateExpirationDate: $scope.supplierInfo.minorityBusinessCertificateExpirationDate,
               	score: $scope.supplierInfo.minorityBusinessScore
            },
            serviceDisabledVeteranSmallBusiness: {
              	apply: $scope.supplierInfo.serviceDisabledVeteranSmallBusiness,
              	certificateDocumentId: $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertId,
              	certificateExpirationDate: $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertificateExpirationDate,
               	score: $scope.supplierInfo.serviceDisabledVeteranSmallBusinessScore
            },
            smallDisadvantagedBusiness: {
              	apply: $scope.supplierInfo.smallDisadvantagedBusiness,
              	certificateDocumentId: $scope.supplierInfo.smallDisadvantagedBusinessCertId,
              	certificateExpirationDate: $scope.supplierInfo.smallDisadvantagedBusinessCertificateExpirationDate,
               	score: $scope.supplierInfo.smallDisadvantagedBusinessScore
            },
            veteranOwnedSmallBusiness: {
              	apply: $scope.supplierInfo.veteranOwnedSmallBusiness,
              	certificateDocumentId: $scope.supplierInfo.veteranOwnedSmallBusinessCertId,
              	certificateExpirationDate: $scope.supplierInfo.veteranOwnedSmallBusinessCertificateExpirationDate,
               	score: $scope.supplierInfo.veteranOwnedSmallBusinessScore
            },
            womenOwnedSmallBusiness: {
              	apply: $scope.supplierInfo.womenOwnedSmallBusiness,
              	certificateDocumentId: $scope.supplierInfo.womenOwnedSmallBusinessCertId,
              	certificateExpirationDate: $scope.supplierInfo.womenOwnedSmallBusinessCertificateExpirationDate,
               	score: $scope.supplierInfo.womenOwnedSmallBusinessScore
            }
		}

		// WfModel.supplier.diversity = {};
		// angular.forEach($scope.diversities.data, function(value, key) {
		// 	console.log(value.diversityCheckBox);
		// 	if(value.diversityCheckBox) {
		// 		var obj = 
		// 			{
		// 			  "apply": true, 
		// 			  "certificateDocumentId": value.uploadUrl, 
		// 			  "certificateExpirationDate": {  
		// 				"day": 0,
		// 				"fractionalSecond": 0,
		// 				"hour": 0,
		// 				"millisecond": 0,
		// 				"minute": 0,
		// 				"month": 0,
		// 				"second": 0,
		// 				"timezone": 0
		// 			  },
		// 			  "id": value.id,  
		// 			  "score": value.score  
		// 			};
		// 		console.log(obj);	
				
		// 		WfModel.supplier.diversity.push(obj); 
				 
		// 	}
		// });
		
		WorkFlow.setVariablesV2(WfModel).then(function(data){
			$scope.loader=false;
			if(text==true){
				$state.go('supplierProfileDueDiligence');
			}
			$rootScope.supplierProfileDiversityDone=true;
			toaster.pop('success', "Saved successfully");
		},function(data){
			$scope.loader=false;
			toaster.pop('error', "Workflow Api failed");
		});
		/*
		var obj = [{name: 'diversityPage', value: JSON.stringify($scope.diversity)}];
		WorkFlow.setVariables(obj, WorkFlow.getInstance()).then(function(data){
			
			toaster.pop('success', "Saved successfully");	
			
		},function(data){
			toaster.pop('error', "Workflow Api failed");
		}); */
		

	}

	$scope.eventId = "";
	$scope.getCurrentIdFound = "";
	var eventIdTrack;
	var currentId;

	/****************************Certification section for drag and drop*********************************/

	//certification file download flags
	$scope.fileDownload_isoCert=false;
	$scope.fileDownload_otherCert=false;
	
	//drag and drop for certification files upload.
	var dropbox1 = document.getElementById("dropbox_isoCert");
	var dropbox2 = document.getElementById("dropbox_otherCert");
	
	function dragEnterLeave(evt) {
	     	$("#uploadFile").trigger('change');
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        }) 
    }
	
	//For dropbox 1
	dropbox1.addEventListener("dragenter", dragEnterLeave, false)
    dropbox1.addEventListener("dragleave", dragEnterLeave, false)
    dropbox1.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox1.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)
    
    //for dropbox 2
	dropbox2.addEventListener("dragenter", dragEnterLeave, false)
    dropbox2.addEventListener("dragleave", dragEnterLeave, false)
    dropbox2.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox2.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

	/****************************Diversity section for drag and drop*********************************/

    //diversity ile download flags
	$scope.fileDownload_alaskaNativeAndIndianCertId=false;
	$scope.fileDownload_blackOwnedCertId=false;
	$scope.fileDownload_historicallyBlackCollegesCertId=false;
	$scope.fileDownload_historicallyUnderutilizedBusinessCertId=false;
	$scope.fileDownload_lgbtBusinessCertId=false;
	$scope.fileDownload_minorityBusinessCertId=false;
	$scope.fileDownload_serviceDisabledVeteranSmallBusinessCertId=false;
	$scope.fileDownload_smallDisadvantagedBusinessCertId=false;
	$scope.fileDownload_veteranOwnedSmallBusinessCertId=false;
	$scope.fileDownload_womenOwnedSmallBusinessCertId=false;
    
	//drag and drop for diversity files upload.
	var dropbox3  = document.getElementById("dropbox_alaskaNativeAndIndianCertId");
	var dropbox4  = document.getElementById("dropbox_blackOwnedCertId");
	var dropbox5  = document.getElementById("dropbox_historicallyBlackCollegesCertId");
	var dropbox6  = document.getElementById("dropbox_historicallyUnderutilizedBusinessCertId");
	var dropbox7  = document.getElementById("dropbox_lgbtBusinessCertId");
	var dropbox8  = document.getElementById("dropbox_minorityBusinessCertId");
	var dropbox9  = document.getElementById("dropbox_serviceDisabledVeteranSmallBusinessCertId");
	var dropbox10 = document.getElementById("dropbox_smallDisadvantagedBusinessCertId");
	var dropbox11 = document.getElementById("dropbox_veteranOwnedSmallBusinessCertId");
	var dropbox12 = document.getElementById("dropbox_womenOwnedSmallBusinessCertId");

	function dragEnterLeave(evt) {
	     	$("#uploadFile").trigger('change');
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        }) 
    }
	    
	//For dropbox 3
	dropbox3.addEventListener("dragenter", dragEnterLeave, false)
    dropbox3.addEventListener("dragleave", dragEnterLeave, false)
    dropbox3.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox3.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)
    
    //for dropbox4
	dropbox4.addEventListener("dragenter", dragEnterLeave, false)
    dropbox4.addEventListener("dragleave", dragEnterLeave, false)
    dropbox4.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox4.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 5
	dropbox5.addEventListener("dragenter", dragEnterLeave, false)
    dropbox5.addEventListener("dragleave", dragEnterLeave, false)
    dropbox5.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox5.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 6
	dropbox6.addEventListener("dragenter", dragEnterLeave, false)
    dropbox6.addEventListener("dragleave", dragEnterLeave, false)
    dropbox6.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox6.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 7
	dropbox7.addEventListener("dragenter", dragEnterLeave, false)
    dropbox7.addEventListener("dragleave", dragEnterLeave, false)
    dropbox7.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox7.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 8
	dropbox8.addEventListener("dragenter", dragEnterLeave, false)
    dropbox8.addEventListener("dragleave", dragEnterLeave, false)
    dropbox8.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox8.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 9
	dropbox9.addEventListener("dragenter", dragEnterLeave, false)
    dropbox9.addEventListener("dragleave", dragEnterLeave, false)
    dropbox9.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox9.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 10
	dropbox10.addEventListener("dragenter", dragEnterLeave, false)
    dropbox10.addEventListener("dragleave", dragEnterLeave, false)
    dropbox10.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox10.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 11
	dropbox11.addEventListener("dragenter", dragEnterLeave, false)
    dropbox11.addEventListener("dragleave", dragEnterLeave, false)
    dropbox11.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox11.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox 12
	dropbox12.addEventListener("dragenter", dragEnterLeave, false)
    dropbox12.addEventListener("dragleave", dragEnterLeave, false)
    dropbox12.addEventListener("dragover", function(evt) {
    	$($scope.getCurrentIdFound).css("background-color","#eaf1f8");
    	currentId = evt.currentTarget.id;
    	$scope.getCurrentIdFound = "#"+currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color","orange");
    	$scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function(){
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox12.addEventListener("drop", function(evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function(){
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function(){
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                     uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //set the files
    $scope.setFiles = function(element) {
		var getElementId=element.id.split('_');
		$scope.eventId = getElementId[1]; 
	    $scope.$apply(function($scope) {
        $scope.files = []
        for (var i = 0; i < element.files.length; i++) {
          $scope.files.push(element.files[i]);
          uploadFileSend($scope.files[0])
        }
      });
    };

    //upload the file
	function uploadFileSend(file){
		$scope.loader=true; 
		console.log("supplierApiUrl",constants.SUPPLIER_API_URL);
		console.log("file",file);
	    $($scope.getCurrentIdFound).css("background-color","#eaf1f8");
		$scope.preloader=true;
		$scope.fileName=file.name;
		var formData = new FormData();
		formData.append('file', file);
		formData.append('SUPPLIERID', localStorage.getItem("userId"));
		console.log("formData",formData)
		var req = {
			method : 'POST',
			url :constants.FILE_UPLOAD+$scope.eventId ,
			transformRequest: angular.identity,
			headers : {
				'Content-Type': undefined,
				'Authorization' : WorkFlow.getCookieVal()
			},
			    data: formData,
			    cache: false,
			    contentType: false,
			    processData: false
		};
		$http(req).then(function(data) {
			var divAttribute;
			var downloadUrl;
			var userId=localStorage.getItem("userId");					
			$scope.getCurrentIdFound = "";
			$scope.eventId = "";
			$scope.preloader=false;
			var pJson=data.data;
			var finalUrlData=pJson.key;
			var dataFile=finalUrlData.split(':');
			var docName=data.data.docType;
            var specificFileName=dataFile[3];                    
            $scope.loader=false;
			toaster.pop('success', "Document Upload", "Document had been uploaded successfully");
			if(dataFile[1]=="isoCert"){
				$scope.fileDownload_isoCert=true;
				$scope.fileNameIsoCert=dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.isoCertDocName=$scope.fileNameIsoCert;
				$scope.supplierInfo.isoCertPath=downloadUrl.split('/').pop();
				$scope.supplierInfo.isoCertificationsCertDocId = $scope.supplierInfo.isoCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_isoCert');
				divAttribute.href = '/pc_document_management'+downloadUrl;
				
			}
			else if(dataFile[1]=="otherCert"){
				$scope.fileDownload_otherCert=true;						
				$scope.fileNameOtherCert = dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.otherCertName = $scope.fileNameOtherCert;
				$scope.supplierInfo.otherCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.otherCertificationsCertDocId = $scope.supplierInfo.otherCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_otherCert');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="alaskaNativeAndIndianCertId"){
				$scope.fileDownload_alaskaNativeAndIndianCertId=true;						
				$scope.fileNameAlaskaNativeAndIndianCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.alaskaNativeAndIndianCertName = $scope.fileNameAlaskaNativeAndIndianCert;
				$scope.supplierInfo.alaskaNativeAndIndianCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.alaskaNativeAndIndianCertId = $scope.supplierInfo.alaskaNativeAndIndianCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_alaskaNativeAndIndianCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="blackOwnedCertId"){
				$scope.fileDownload_blackOwnedCertId=true;						
				$scope.fileNameBlackOwnedCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.blackOwnedCertName = $scope.fileNameBlackOwnedCert;
				$scope.supplierInfo.blackOwnedCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.blackOwnedCertId = $scope.supplierInfo.blackOwnedCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_blackOwnedCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="historicallyBlackCollegesCertId"){
				$scope.fileDownload_historicallyBlackCollegesCertId=true;						
				$scope.fileNameHistoricallyBlackCollegesCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.historicallyBlackCollegesCertName = $scope.fileNameHistoricallyBlackCollegesCert;
				$scope.supplierInfo.historicallyBlackCollegesCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.historicallyBlackCollegesCertId = $scope.supplierInfo.historicallyBlackCollegesCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_historicallyBlackCollegesCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="historicallyUnderutilizedBusinessCertId"){
				$scope.fileDownload_historicallyUnderutilizedBusinessCertId=true;						
				$scope.fileNameHistoricallyUnderutilizedBusinessCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.historicallyUnderutilizedBusinessCertName = $scope.fileNameHistoricallyUnderutilizedBusinessCert;
				$scope.supplierInfo.historicallyUnderutilizedBusinessCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.historicallyUnderutilizedBusinessCertId = $scope.supplierInfo.historicallyUnderutilizedBusinessCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_historicallyUnderutilizedBusinessCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="lgbtBusinessCertId"){
				$scope.fileDownload_lgbtBusinessCertId=true;						
				$scope.fileNameLgbtBusinessCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.lgbtBusinessCertName = $scope.fileNameLgbtBusinessCert;
				$scope.supplierInfo.lgbtBusinessCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.lgbtBusinessCertId = $scope.supplierInfo.lgbtBusinessCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_lgbtBusinessCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="minorityBusinessCertId"){
				$scope.fileDownload_minorityBusinessCertId=true;						
				$scope.fileNameMinorityBusinessCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.minorityBusinessCertName = $scope.fileNameMinorityBusinessCert;
				$scope.supplierInfo.minorityBusinessCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.minorityBusinessCertId = $scope.supplierInfo.minorityBusinessCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_minorityBusinessCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="serviceDisabledVeteranSmallBusinessCertId"){
				$scope.fileDownload_serviceDisabledVeteranSmallBusinessCertId=true;						
				$scope.fileNameServiceDisabledVeteranSmallBusinessCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertName = $scope.fileNameServiceDisabledVeteranSmallBusinessCert;
				$scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertId = $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_serviceDisabledVeteranSmallBusinessCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="smallDisadvantagedBusinessCertId"){
				$scope.fileDownload_smallDisadvantagedBusinessCertId=true;						
				$scope.fileNameSmallDisadvantagedBusinessCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.smallDisadvantagedBusinessCertName = $scope.fileNameSmallDisadvantagedBusinessCert;
				$scope.supplierInfo.smallDisadvantagedBusinessCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.smallDisadvantagedBusinessCertId = $scope.supplierInfo.smallDisadvantagedBusinessCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_smallDisadvantagedBusinessCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="womenOwnedSmallBusinessCertId"){
				$scope.fileDownload_womenOwnedSmallBusinessCertId=true;						
				$scope.fileNameWomenOwnedSmallBusinessCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.womenOwnedSmallBusinessCertName = $scope.fileNameWomenOwnedSmallBusinessCert;
				$scope.supplierInfo.womenOwnedSmallBusinessCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.womenOwnedSmallBusinessCertId = $scope.supplierInfo.womenOwnedSmallBusinessCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_womenOwnedSmallBusinessCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
			else if(dataFile[1]=="veteranOwnedSmallBusinessCertId"){
				$scope.fileDownload_veteranOwnedSmallBusinessCertId=true;						
				$scope.fileNameVeteranOwnedSmallBusinessCert= dataFile[3];
				downloadUrl=data.data.filePath;
				$scope.supplierInfo.veteranOwnedSmallBusinessCertName = $scope.fileNameVeteranOwnedSmallBusinessCert;
				$scope.supplierInfo.veteranOwnedSmallBusinessCertPath = downloadUrl.split('/').pop();
				$scope.supplierInfo.veteranOwnedSmallBusinessCertId = $scope.supplierInfo.veteranOwnedSmallBusinessCertPath;
				divAttribute = document.getElementById('downloadUrlForFile_veteranOwnedSmallBusinessCertId');
				divAttribute.href = '/pc_document_management'+downloadUrl;	
			}
		}, function() {
			$scope.loader=false;
			$scope.eventId = "";
			$scope.getCurrentIdFound = "";
			$scope.preloader=false;
			toaster.pop('error', "Document Upload", "server not responding");
		});	
	}
});