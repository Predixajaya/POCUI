var searchController = app.controller('searchController', function($scope, $stateParams, $filter, $http, $rootScope, $state, Auth, $timeout, toaster, constants,
    $cookies, $cookieStore, $location, WorkFlow, supplier, roles) {

    $rootScope.roleActions = roles;
    $scope.supplier = {};
    $scope.flagValue = false;
    $scope.supplierInfo = {};
    $scope.companyFile = {};
    $scope.isoFile = {};
    $scope.TaxRegFileCross = {};
    $scope.additionalCertificateFile = {};
    $scope.alaskaNativeAndIndianFile = {};
    $scope.blackOwnedFile = {};
    $scope.historicallyUnderutilizedFile = {};
    $scope.historicallyBlackFile = {};
    $scope.lgbtBusinessFile = {};
    $scope.minorityBusinessFile = {};
    $scope.serviceDisabledVeteranFile = {};
    $scope.smallDisadvantagedFile = {};
    $scope.womenOwnedSmallBusinessFile = {};
    $scope.veteranOwnedSmallBusinessFile = {};
    $scope.vatDocFile = {};
    $scope.TaxRegFile = {};
    $scope.TaxExemptFile = {};
    $scope.TaxRegFileLegal = {};
	$scope.addressTypes = {};
	$scope.panel = {};
    $scope.loader = false;
    $scope.remittanceEmailSection = false;

    Auth.getRoles().then(function(roles){ 
        if (Auth.isSupplierRole(roles.roles)){
            $state.go('supplierHome');
        }

    }, function(data){
        $scope.loader=false;
    });


    $scope.inviteSupplier = function() {
        
        $rootScope.businessList2 = [];
        $rootScope.businessList3 = [];
        $rootScope.businessTableList = [];
        $scope.loader = true;
        //########if you want to run from local comment this################
	    Auth.getRoles().then(function(roles){			
			 if (Auth.isRoleExists(roles.authorities , 'ADD_SUPPLIER')){
		     	$scope.inviteEnabled = true;
		     }
			$cookieStore.put("uId", roles.id); 
		    // $scope.inviteEnabled = true
			console.log($scope.inviteEnabled)
			if($scope.inviteEnabled) {
				
				WorkFlow.startInstanceV2().then(function(data){
					$scope.loader=false;
					if(data.requestId){
						console.log(data);
						WorkFlow.setInstance(data.instanceId);
						WorkFlow.setTask(data.taskId);
						WorkFlow.setRequestId(data.requestId);
						$state.go('supplierInfo');
					}
					else{

						toaster.pop('error', "No Request Id found !", "Request Id is retrieving as null");
						$state.go('homePage');
						
						return
					}
			},function(data){
				$scope.loader=false;
			});

			} else {
				$scope.loader=false;
				toaster.pop('error', "Access Denied", "You don't have permission to add supplier");
			}
			
		}, function() {
			$scope.loader=false;
			toaster.pop('error', "Role list", "server not responding");
		});	
        //####################################################################

        //########if you want to run from local uncomment this################
       // $scope.inviteEnabled = true;
       // if ($scope.inviteEnabled) {

       //     WorkFlow.startInstanceV2().then(function(data) {
       //         $scope.loader = false;
       //         if (data.requestId) {
       //             console.log(data);
       //             WorkFlow.setInstance(data.instanceId);
       //             WorkFlow.setTask(data.taskId);
       //             WorkFlow.setRequestId(data.requestId);
       //             $state.go('supplierInfo');
       //         } else {

       //             toaster.pop('error', "No Request Id found !", "Request Id is retrieving as null");
       //             $state.go('homePage');

       //             return
       //         }
       //     }, function(data) {
       //         $scope.loader = false;
       //     });
       // } else {
       //     $scope.loader = false;
       //     toaster.pop('error', "Access Denied", "You don't have permission to add supplier");
       // }
        // ####################################################################
    }

    /*
    $scope.focusSearch = function (text) {
    	$scope.supplierInfo.text= text;
    	$scope.typeAheadData =[];
    	$scope.doSearch();
    }
    */
    
    //search options (External vs Internal)
    $scope.changeSearch={};
    $scope.query = $stateParams.query;
    if($stateParams.activeSearch === "false"){
        $scope.changeSearch.searchOptions = false;
        $scope.placeholder = "Business Unit Code (BUC), Company Code";
        $scope.internalSupplier=true;
        
    }else{
        $scope.changeSearch.searchOptions = true;
        $scope.placeholder = "ID, Supplier Name, DBA, Country, Address";
        $stateParams.activeSearch = "true";
    }
    //$scope.placeholder = "ID, Supplier Name, DBA, Country, Address";
    $scope.changeSearchOptions = function(changeSearch){
        if(changeSearch.searchOptions == true){
            $scope.placeholder = "ID, Supplier Name, DBA, Country, Address";
            $rootScope.activeSupplierSearch = true;
            $stateParams.activeSearch = "true";
            searchByIndexIdCall();
            $scope.externalSupplierSearch = true;
            $scope.internalSupplierSearch = false;
        }else if(changeSearch.searchOptions == false){
            $scope.placeholder = "Business Unit Code (BUC), Company Code";
            $rootScope.activeSupplierSearch = true;
            $stateParams.activeSearch = "false";
            searchByIndexIdCall();
            $scope.internalSupplierSearch = true;
            $scope.externalSupplierSearch = false; 
        }
    }
    $scope.typeAhead = function(viewValue) {
        // var searchTerms = {
        //     text: viewValue,
        //     highlight: true,
        //     limit: 15
        // };
        // var url = constants.LOOKHEAD_SEARCH;
        // var cookie = $cookieStore.get("sc_token");
        // var auth = {
        //     headers: {
        //         'Content-Type': 'application/json',
        //         'Authorization': cookie
        //     }
        // };
        // return $http.post(url, searchTerms, auth).then(function(result) {
        //     console.log("suggestions", result.data.data.suggestions);
        //     return result.data.data.suggestions;
        // });

        if($scope.changeSearch.searchOptions){
            var url = constants.LOOKHEAD_SEARCH;
            var searchTerms = {text: viewValue,highlight: true, limit: 15};
        }else{
            var url = constants.INTERNAL_LOOKHEAD_SEARCH;
            var searchTerms = {text: viewValue,highlight: true, limit: 10};
        }
        var cookie = $cookieStore.get("sc_token");
        var auth = {
            headers:{
                'Content-Type':  'application/json',
                'Authorization': cookie
            }
        };
        return $http.post(url, searchTerms, auth).then(function(result){
            return result.data.data.suggestions;
            var resultdata = result.data.data.suggestions;
        });
    };
    //regular search on search page
    $scope.dosearch = function() {
        var obj = {
            "text": ($scope.query.indexId) ? $scope.query.indexId : '',
            "query": ($scope.query) ? $scope.query : ''
        }
        supplier.setSearchParams(obj);
        searchByIndexIdCall();
    }
    $scope.onSelect = function($item, $model, $label, $event) {
        $scope.query = $label.replace(/<b>/g, '').replace(/<\/b>/g, '');
        $scope.text = $item.indexId;
        var obj = {
            "text": ($scope.text) ? $scope.text : '',
            "query": ($scope.query) ? $scope.query : ''
        }
        supplier.setSearchParams(obj);
        searchByIndexIdCall();
    }
    
    $scope.magnifierClick = function() {
    	$scope.dosearch();
    }

    /** pagination **/
    //$scope.sortingOrder = sortingOrder;
    $scope.reverse = false;
    $scope.filteredItems = [];
    $scope.groupedItems = [];
    $scope.itemsPerPage = 10;
    $scope.pagedItems = [];
    $scope.currentPage = 0;

    // init the filtered items
    $scope.search = function() {
        if ($scope.items == undefined) {
            $scope.filteredItems = 0;
            $scope.noResult = true;
        } else {
            $scope.filteredItems = $scope.items;
        }
        //$scope.currentPage = 0;
        // now group by pages
        $scope.groupToPages();
    };

    // calculate page in place
    $scope.groupToPages = function() {
        $scope.pagedItems = [];

        for (var i = 0; i < $scope.filteredItems.length; i++) {
            if (i % $scope.itemsPerPage === 0) {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [$scope.filteredItems[i]];
            } else {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
            }
        }
    };

    $scope.range = function(start, end) {
        var ret = [];
        if (!end) {
            end = start;
            start = 0;
        }
        for (var i = start; i < end; i++) {
            ret.push(i);
        }
        return ret;
    };

    $scope.prevPage = function() {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };

    $scope.nextPage = function() {
        if ($scope.currentPage < $scope.pagedItems.length - 1) {
            $scope.currentPage++;
        }
    };

    $scope.setPage = function() {
        $scope.currentPage = this.n;
    };

    $scope.shortPages = function(total, current) {
        //console.log("total", total);
        ////console.log("current", current);
        //console.log("$scope.currentPage", $scope.currentPage);
        if (($scope.currentPage - 3) < current && current < ($scope.currentPage + 3)) {
            return true;
        }
        return false
    }


    //search call for specific typeahead search
    var searchByIndexIdCall = function() {
        var searchObj = supplier.getSearchParams();
        var searchText = {};
        if (searchObj) {
            $scope.loader = true;
        }
        if (searchObj.text == "") {
            searchText.text = searchObj.query;
            //check if the search is external or internal search
            if($stateParams.activeSearch === "true"){
                // supplier.fullSearch(searchText).then(function(data) {
                //     console.log(data.data.hits);
                //     $scope.totalCount = data.data.count;
                //     $scope.searchResults = data.data.hits;
                //     $scope.loader = false;
                //     $scope.items = $scope.searchResults;
                //     $scope.externalSupplierSearch = true;
                //     // functions have been describe process the data for display
                //     $scope.search();
                // }, function(data) {
                //     $scope.loader = false;
                // });
                searchText.internal ="false";
                $scope.externalSupplierSearch = true;
            }else{
                searchText.internal ="true";
                $scope.internalSupplierSearch = true;
            }
                supplier.fullSearch(searchText).then(function(data) {
                    console.log(data.data.hits);
                    $scope.totalCount = data.data.count;
                    $scope.searchResults = data.data.hits;
                    $scope.items = $scope.searchResults;
                    // $scope.internalSupplierSearch = true;
                    $scope.loader = false;
                    // functions have been describe process the data for display
                    $scope.search();
                }, function(data) {
                    $scope.loader = false;
                });
            // }
        }else if (searchObj.text == undefined) {
            $scope.loader = false;
            return;
        }else {
            if($stateParams.activeSearch === "true"){
                // supplier.searchByIndexId(searchObj).then(function(data) {
                //     console.log(data.data.hits);
                //     $scope.searchResults = data.data.hits;
                //     $scope.loader = false;
                //     $scope.items = $scope.searchResults;
                //      $scope.externalSupplierSearch = true;
                //     // functions have been describe process the data for display
                //     $scope.search();
                // }, function(data) {
                //     $scope.loader = false;
                // });
                var indexSearchObj = {
                    "id": searchObj.text,
                    "internal":"false"
                };
                $scope.externalSupplierSearch = true;
            }else{
                var indexSearchObj = {
                    "id": searchObj.text,
                    "internal":"true"
                };
                $scope.internalSupplierSearch = true;
            }
                supplier.fullSearch(indexSearchObj).then(function(data) {                    
					//var data = {"data":{"requestTimestamp":"2017-01-02T10:12:33Z","count":1,"hits":[{"rootId":"34102","rootType":"supplier","supplierName":"JBehave Add new address 2016-12-27T16:07:17.079Z 5b3384b9-9dd0-46c2-a608-342cad4fb3ea","scid":"S11477-000","taxId":"213213123","address":"Legal Line 1, Stamford, Delaware, 22222, US","country":"US","status":"Active","type":"Legal entity","subscriptionCount":"0","tags":[]}]}};
                    $scope.searchResults = data.data.hits;
                    $scope.loader = false;
                    $scope.items = $scope.searchResults;
                    // $scope.internalSupplierSearch = true;
                    // functions have been describe process the data for display
                    $scope.search();
                }, function(data) {
                    $scope.loader = false;
                });
            
        }
    }
    searchByIndexIdCall();
    $scope.addSubscribersFromAddTab = function(item, text) {
        $scope.addressSubscribersArray = [];
        $scope.paymentSubscribersArray = [];
        $scope.contactSubscribersArray = [];
        angular.forEach($scope.mainArrayForAddNewSection, function(item, index) {
        	  if(item.check==true && text == "address"){
        		  $scope.addressSubscribersArray.push(item.id)
        	  }
        	  if(item.check==true && text == "payment"){
        		  $scope.paymentSubscribersArray.push(item.id)
        	  }
        	  if(item.check==true && text == "contact"){
        		  $scope.contactSubscribersArray.push(item.id)
        	  }

        	});
    }


    supplier.getPhoneCodes().then(function(data) {
        $scope.phoneCodesGeneral = data;
    }, function() {
        toaster.pop('error', "Phone list", "server not responding");
    });
    $scope.goSubscribe = function(panel) {
        
        $scope.loader = true;
        $scope.supplierSubscribingTo = $stateParams.activeSearch;
        if($scope.supplierSubscribingTo === "true"){
            var obj= {
                "processType": "SUBSCRIBE"
            }
        }else{
            var obj= {
                "processType": "SUBSCRIBE_INTERNAL"
            }
        }
        supplier.processTypeSubscribe(obj).then(function(data) {
            $scope.loader = false;
            if (data.requestId) {
                $cookieStore.put("subscribeRequestId", data.requestId);
            }
            if (data.taskId) {
                $cookieStore.put("subscribeTaskId", data.taskId);
            }
            if (data.instanceId != "" || data.taskId != "" || data.requestId != "") {
                $cookieStore.put("roleForSubscribe", panel.rootType);
                $cookieStore.put("supplierIdForSubscribe", panel.rootId);
                $cookieStore.put("basicSubscribeDetailsForRow", panel);

                $state.go('subscribe', {
                    obj: panel,
                    supplierSubscribingTo: $scope.supplierSubscribingTo
                });
            }
        }, function() {
            $scope.loader = false;
            toaster.pop('error', "Process Type Api Fails", "server not responding");
        });
    }

    supplier.getCountryList().then(function(data) {
        $scope.chooseCountries = data;
    }, function() {
        toaster.pop('error', "Country list", "server not responding");
    });

    supplier.getCurrencyList().then(function(data) {
        $scope.currencyList = data;
    }, function() {
        toaster.pop('error', "Currency list", "server not responding");
    });
    $scope.maskNumber = function(number) {
        number = (number) ? number + "" : "";
        return number.replace(/\d(?=\d{4})/g, "*");
    }

    supplier.getAgentTypes().then(function(data) {
        $scope.agentTypes = data;
    }, function() {
        toaster.pop('error', "Country list", "server not responding");
    });
    supplier.getCountryList().then(function(data) {
        $scope.chooseCountries = data;
    }, function() {
        toaster.pop('error', "Country list", "server not responding");
    });

    $scope.dependantTaxClassify = function(countryCode) {

        $scope.loader = true;
        supplier.withHoldingTaxTypes(countryCode).then(function(data) {
            $scope.loader = false;
            $scope.withHoldingTypes = data;
        }, function(data) {
            $scope.loader = false;
            toaster.pop('error', "Tax Types Api Server Not Responding");
        });

    }
    $scope.dependantTaxClassifyForOwner = function(countryCode) {
        angular.forEach($scope.chooseCountries, function(value, key) {
            if (value.name == countryCode) {
                $scope.countryCodeNameForOwner = value.code;
                $scope.loader = true;
                supplier.withHoldingTaxTypes($scope.countryCodeNameForOwner).then(function(data) {
                    $scope.loader = false;
                    $scope.withHoldingTypesForOwner = data;
                }, function(data) {
                    $scope.loader = false;
                    toaster.pop('error', "Tax Types Api Server Not Responding");
                });
            }
        });

        angular.forEach($scope.chooseCountries, function(value, key) {
            if (value.code == countryCode) {
                $scope.countryNameForOwner = value.name;

            }
        });

    }
    $scope.getStateListForAddressCountry = function(item) {
        angular.forEach($scope.chooseCountries, function(value, key) {
            if (value.id == item) {
                supplier.getStatesList(value.code).then(function(data) {
                    $scope.stateLabel = data[0].authorityName;;
                    $scope.stateList = data[0].subdivisions;
                }, function() {
                    toaster.pop('error', "State", "server not responding");
                });
            }
        });
    }
	
	
	$scope.bankRuleUI = function (item) {
		item.showForm = false;
		item.failingCaseTrue = false;

        var ruleObj = {
            "request": {
                "isElectronicBanking": ($scope.notElectronic) ? ($scope.notElectronic) : true,
                "erpIds": [],
                "banks": [
                    {
                        "bankCountry": item.bankCountryCode,
                        "isUseFurtherCreditTo": (item.bankCreditDetails) ? (item.bankCreditDetails) : false,
                        "id": "123"
                    }
                ]
            }
        }
        supplier.getBankUIRule(ruleObj).then(function (data) {
            item.bankRule = data;			
        }, function () {
            toaster.pop('error', "Bank Rule", "server not responding");
        });

        // reset IBAN and AC number on change
        // $scope.supplierInfo.iban = undefined;
        // $scope.supplierInfo.maskedAccountNumber = undefined;		

    }
	
	$scope.getStateListForBankCountry = function (item) {
		item.stateBankLabel = 'State';                    
        item.stateBankList = '';
		
        angular.forEach($scope.chooseCountries, function (value, key) {
            if (value.id == item.country_name) {
                supplier.getStatesList(value.code).then(function (data) {
                    item.stateBankLabel = data[0].authorityName;                    
                    item.stateBankList = data[0].subdivisions;
                }, function () {
                    toaster.pop('error', "State", "server not responding");
                });
            }
        });


    }

    supplier.getBusinessList1().then(function(data) {
        $scope.businessList1 = data;
    }, function() {
        $scope.loader = false;
        toaster.pop('error', "Business Root list", "server not responding");
    });
    $scope.onbusinessList1ChangeCode = function(id) {
        $scope.loader = true;
        if (id == undefined) {
            $scope.loader = false;
            return;
        } else {
            $scope.getBusinessList2(id);
        }
    }
    $scope.getBusinessList2 = function(id) {
        $scope.loader = true;
        if (id == undefined) {
            $rootScope.businessList2 = [];
            $rootScope.businessList3 = [];
            $rootScope.businessTableList = [];
            $scope.loader = false;
            return;
        } else {

            supplier.getBusinessSubList(id).then(function(data) {
                $rootScope.businessList2 = data;
                $scope.loader = false;
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "Business sub list", "server not responding");
            });
        }
    }
    $scope.getBusinessList3 = function(id) {
            $scope.loader = true;
            if (id == undefined) {
                $rootScope.businessList3 = [];
                $rootScope.businessTableList = [];
                $scope.loader = false;
                return;
            } else {
                supplier.getBusinessSubList(id).then(function(data) {
                    $rootScope.businessList3 = data;
                    $scope.loader = false;
                }, function() {
                    $scope.loader = false;
                    toaster.pop('error', "Business sub list", "server not responding");
                });
            }
        }
        //$rootScope.businessTableList=[];

    $scope.getStateListForAddressCountryInAdd = function(item) {
        $scope.loader=true;
        if(item==undefined){
            $scope.loader=false;
            $scope.stateList = [];
            $scope.stateLabel ="";
            $scope.loader=false;
            return;
        }else{
            supplier.getStatesList(item).then(function(data) {
                $scope.stateLabel = data[0].authorityName;
                $scope.stateList = data[0].subdivisions;
                $scope.loader=false;
            }, function() {
                $scope.loader=false;
                toaster.pop('error', "State", "server not responding");
            });
        }  
    }

    $scope.getBusinessList4 = function(id) {
        $scope.loader = true;
        if (id == undefined) {
            $rootScope.businessTableList = [];
            $scope.loader = false;
            return;
        } else {
            $rootScope.businessTableList = [];
            supplier.getBusinessSubListNew(id).then(function(data) {
                $rootScope.businessTableList = data;
                $scope.loader = false;
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "Business sub list", "server not responding");
            });
        }
    }
    $scope.setCurrency = function(item) {
        //console.log(code);
        $scope.loader = true;
		item.bankCurrency = "";
        supplier.getCountryById(item.bankCountryCode).then(function(data) {
            $scope.loader = false;
            $scope.CountryCode = data.code
            $scope.loader = true;

            supplier.getCountryList($scope.CountryCode).then(function(data) {
                $scope.loader = false;

                angular.forEach(data, function(value, key) {
                    if (value.code === $scope.CountryCode) {
                        var idArray = $filter('filter')($scope.currencyList, {
                            'currencyCode': value.currencyCode
                        });
                        if (idArray[0]) {
                            if (idArray[0].id) {
                                item.bankCurrency = idArray[0].currencyCode;
                            }
                        }
                    }
                })
            }, function() {
                $scope.loader = false;
                //toaster.pop('error', "Country list", "server not responding");
            });
        }, function() {
            $scope.loader = false;
            //toaster.pop('error', "Country list", "server not responding");
        });
    }

    $scope.maskCredit = function(item) {

        if (item.bankCreditNumber.indexOf('*') == -1) {
            item.unmaskedBankCreditNumber = item.bankCreditNumber;
        }

        item.bankCreditNumber = item.bankCreditNumber.replace(/\d(?=\d{4})/g, "*");
    }

    $scope.bankAccountCheck = function(item) {
        var acnumber = item.maskedAccountNumber;
        if (item.maskedAccountNumber.indexOf('*') == -1) {
            item.bankAccountNumber = item.maskedAccountNumber;
        }

        item.maskedAccountNumber = item.maskedAccountNumber.replace(/\d(?=\d{4})/g, "*");
    }

    $scope.setRoutingLabel = function(item) {
        $scope.loader = true;
        supplier.getCountryById(item.bankCountryCode).then(function(data) {
            $scope.loader = false;
            $scope.CountryCode = data.code
            $scope.loader = true;
            supplier.getRoutingLabel($scope.CountryCode).then(function(data) {
                $scope.loader = false;
                if (data[0]) {
                    item.routingLabel = data[0].routingCode;
                    item.routingTooltip = data[0].definitionTxt;
                    $scope.accountTooltip = data[0].accountFormatTooltip;
                    if ($scope.accountTooltip === null) {
                        item.accountTooltip = 'Please enter Account Number';
                    }
                } else {
                    item.routingLabel = 'Bank Code';
                    item.routingTooltip = 'Bank Code';
                    item.accountTooltip = 'Please enter Account Number';
                }
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "Routing Label", "server not responding");
            });
        }, function() {
            $scope.loader = false;
        });
    }

    $scope.firstTabClick = function() {
        $scope.companyEditNonSection = true;
        $scope.companyEditSection = false;
        $scope.editCompanyBtn = true;
    }


    $scope.switchTabNew = function(item, tab) {
        item.companyTab = false;
        item.addressTab = false;
        item.paymentTab = false;
        item.contactTab = false;
        item.paytermsTab = false;
        item.commodityTab = false;
        item.certificationTab = false;
        item[tab] = true;
        $scope.contactSectionNew = true;
        $scope.companyEditNonSection=true;
        $scope.showPayterms = false;
        $scope.payTermBtn = true;
        $scope.changeCommodity = true;
        $scope.addressNewSection=true;
        $scope.commodityNonEditSection = true;
        $scope.payTermSectionNonEdit = true;
        $scope.changeCommoditySection = false;
        $scope.editAddressSection = false;
        $scope.addressHeadSection = true;
        $scope.bankAccountsDetails = true;
        $scope.paymentSubscribeSection = false;
        $scope.addressBtn = true;
        $scope.AddressSubscribeSection = false;
        $scope.contactSubscribeSection = false;
        $scope.editCertification = false;
        $scope.certificationNonEdit = true;
        $scope.editCertificationIcon = true;
        $scope.editForBankSection = false;
        $scope.addressNonEditSection = true;
        $scope.contactNonEditSection = true;
        $scope.editContactSection = false;
        $scope.addAddressSection = false;
        $scope.bankHeader = true;
        $scope.addPaymentBtn = true;
        $scope.addPaymentSection = false;
        $scope.addNewContact = true;
        $scope.addContactSection = false;

        if ($cookieStore.get("searchTaskId")) {

            WorkFlow.cancelWorkflowV2($cookieStore.get("searchTaskId")).then(function(data) {
                $cookieStore.remove("searchTaskId")
            }, function() {
                $scope.loader = false;
            });
        }

    }

    $scope.divrsityMap = [{
        key: 'WOMEN_OWNED_SB',
        value: 'Women-owned small businesses'
    }, {
        key: 'DISADVANTAGED_SB',
        value: 'Small disadvantaged businesses'
    }, {
        key: 'VETERAN_OWNED_SB',
        value: 'Veteran-owned small businesses'
    }, {
        key: 'SERVICE_DISABLED_VETERAN_OWNED_SB',
        value: 'Service disabled veteran-owned small business'
    }, {
        key: 'HUB_ZONE_B',
        value: 'Historically underutilized business zones (HUB zone business)'
    }, {
        key: 'HISTORICALY_BLACK_CUMI',
        value: 'Historically black colleges & universities/minority institutions'
    }, {
        key: 'ALASKA_NATIVE_CORP',
        value: 'Alaska Native Corporations(ANCs) and Indian Tribes'
    }, {
        key: 'BLACK_OWNED',
        value: 'Black-owned, managed & controlled supplier certification'
    }, {
        key: 'DISABLED_VETERAN_BE',
        value: 'DISABLED_VETERAN_BE'
    }, {
        key: 'MINORITY_BE',
        value: 'Minority business enterprise/minority owned business'
    }, {
        key: 'ADMINISTRATION_SB',
        value: 'ADMINISTRATION_SB'
    }, {
        key: 'WOMEN_BE',
        value: 'Women-owned small businesses'
    }, {
        key: 'WOMEN_MINORITY_BE',
        value: 'WOMEN_MINORITY_BE'
    }, {
        key: 'BBBEE',
        value: 'BBBEE'
    }, {
        key: 'MSME_IN',
        value: 'MSME_IN'
    }, {
        key: 'MSD_UK',
        value: 'MSD_UK'
    }, {
        key: 'LGBT_BE',
        value: 'Lesbian gay bisexual transgender business enterprise'
    }];


    
    $scope.editCompanyInfo = function(text, panel) {
        $scope.loader = true;
        $scope.companyEditNonSection = true;
        $scope.countryOfIncorporation = $scope.supplierData.countryCodeEditLegalEntityNew;
        $scope.editCompanyBtn = false;
        $scope.companyEditSection = true;
        $scope.companyEditNonSection = false;
        //       supplier.editCreateWorkflow(text).then(function(data) {
        //    	   $scope.loader=false;
        //    	   if(data){
        //    	   $scope.instanceIdForSearch=data.instanceId;
        //    	   $cookieStore.put("searchInstanceId",data.instanceId);
        //    	   $scope.requestIdForSearch=data.requestId;
        //    	   $cookieStore.put("searchRequestId",data.requestId );
        //    	   $scope.taskIdForSearch=data.taskId;
        //    	   $cookieStore.put("searchTaskId",data.taskId);
        //    	   }
        //		    }, function() {
        //	        $scope.loader=false;
        //			});
        $scope.loader=false;
        supplier.getCountryList().then(function(data) {
            $scope.chooseCountries = data;
        }, function() {
            toaster.pop('error', "Country list", "server not responding");
        })
        supplier.getStatesList($scope.supplierData.legalCountry).then(function(data) {

            if (data[0]) {
                $scope.stateLabel = data[0].authorityName;;
                $scope.stateList = data[0].subdivisions;
                $scope.supplierData.legalState = $scope.legalAddresslocation.stateCode;
            }
        }, function() {
            toaster.pop('error', "State", "server not responding");
        });
        supplier.withHoldingTaxTypes(panel.country).then(function(data) {
            $scope.withHoldingTypesForLegal = data;
            $scope.supplierData.taxClassificationLegalEntity = ($scope.supplierData.legalTax) ? $scope.supplierData.legalTax.taxClassification : '';
            $rootScope.taxClassifyValidation = ($scope.supplierData.legalTax) ? $scope.supplierData.legalTax.taxClassification : '';

            angular.forEach($scope.withHoldingTypesForLegal, function(item, index) {
                if (item.id == $scope.supplierData.taxClassificationLegalEntity) {
                    
                    $scope.supplierData.taxClassificationLegalEntity = item.name;
                }
            });
            if ($scope.supplierData.ownerCountryLegalEntity) {
                $scope.supplierData.ownerTaxClassifyLegalEntity = ($scope.supplierData.legalTax) ? $scope.supplierData.legalTax.ownerTaxClassification : '';
                $scope.taxClassifyValidationForOwner = ($scope.supplierData.legalTax) ? $scope.supplierData.legalTax.ownerTaxClassification : '';
                angular.forEach($scope.withHoldingTypesForOwner, function(item, index) {
                    if (item.id == $scope.supplierData.ownerTaxClassifyLegalEntity) {
                        $scope.supplierData.ownerTaxClassifyLegalEntity = item.name;
                    }
                });
            }
        }, function(data) {

            $scope.loader = false;
            toaster.pop('error', "Tax Types Api Server Not Responding");
        });
        if ($scope.supplierData.countryCodeEditLegalEntityNew) {
            supplier.withHoldingTaxTypes($scope.supplierData.countryCodeEditLegalEntityNew).then(function(data) {
                $scope.loader = false;
                $scope.withHoldingTypesForLegal = data;
            }, function(data) {
                $scope.loader = false;
                toaster.pop('error', "Tax Types Api Server Not Responding");
            });
        }

    }
    
    $scope.loadPayTermsOnLoad=function(){
    	$scope.panelPayterms = [];
	    supplier.getSupplierPayterms($scope.supplierIdNew).then(function(data) {			
			data= data.data;
			angular.forEach(data, function(value, key) {
				var temp = {};
				temp.id = value.id;
				supplier.getAllPaymentTermsById(value.id).then(function(payData) {
					temp.name = payData.name;
					$scope.mainPayterm=temp
					$scope.panelPayterms.push(temp);
				}, function() {
	        
				});
				// var idArray =  $filter('filter')(payData.paymentsTerms, {"id": value.id});
				// if(idArray[0]){
				// 	if(idArray[0].name){
				// 		temp.name = idArray[0].name;
				// 	}
				// }
				
			});
				
    	   
		}, function() {
	        
		});
    }

    $scope.loadPayterms = function(item) {
    	
        item.payterms = [];
        supplier.getSupplierPayterms(item.rootId).then(function(data) {
            console.log(item);
            data = data.data;
            supplier.getAllPaymentTerms('', $scope.supplierData.countryCodeEditLegalEntityNew).then(function(payData) {
                angular.forEach(data, function(value, key) {
                    var temp = {};
                    temp.id = value.id;
                    var idArray =  $filter('filter')(payData.paymentsTerms, {"id": value.id});
                    if (idArray[0]) {
                        if (idArray[0].name) {
                            temp.name = idArray[0].name;
                        }
                    }
                    item.payterms.push(temp);
                });
            }, function() {

            });


        }, function() {

        });


    }

    $scope.editClickAddress = function(text, item) {
        $scope.loader = true;
        $scope.addressNewSection = false;
        $scope.addressHeadSection = true;
        $scope.addPaymentSection = false;
        $scope.AddressSubscribeSection = false;
        $scope.addAddressSection = false;
        $scope.addressNonEditSection = false;
        $scope.AddressSubscribeSection = true;
        $scope.addressEntityId = item.entityId;
        $scope.AddressSubscribeSection = false;
        $scope.editAddressSection = !$scope.editAddressSection;
        //       supplier.editCreateWorkflow(text).then(function(data) {
        //    	   $scope.loader=false;
        //    	   if(data){
        //    	   $scope.instanceIdForSearch=data.instanceId;
        //    	   $cookieStore.put("searchInstanceId",data.instanceId);
        //    	   $scope.requestIdForSearch=data.requestId;
        //    	   $cookieStore.put("searchRequestId",data.requestId );
        //    	   $scope.taskIdForSearch=data.taskId;
        //    	   $cookieStore.put("searchTaskId",data.taskId);
        //    	   }
        //		    }, function() {
        //	        $scope.loader=false;
        //			});
        $scope.loader=false;
        $scope.supplierData.addressTypeAddress = (item.addressTypes[0]) ? item.addressTypes : '';
        $scope.supplierData.alternateNameForAddress = (item.addresses) ? item.addresses.alternateName : '';
        $scope.supplierData.addressLine1ForAddress = (item.location) ? item.location.addressLine1 : '';
        $scope.supplierData.addressLine2ForAddress = (item.location) ? item.location.addressLine2 : '';
        $scope.supplierData.addressLine3ForAddress = (item.location) ? item.location.addressLine3 : '';;
        $scope.supplierData.addressLine4ForAddress = (item.location) ? item.location.addressLine4 : ''
        $scope.supplierData.cityNameForAddress = (item.location) ? item.location.cityName : '';

        $scope.supplierData.postalCodeForAddress = (item.location) ? item.location.postalCode : '';

        if (item.location.countryCode) {

            angular.forEach($scope.chooseCountries, function(value, key) {
                if (value.code == item.location.countryCode) {

                    $scope.supplierData.countryCodeForAddress = (value.id) ? value.id : '';
                }
            });

            supplier.getStatesList(item.location.countryCode).then(function(data) {
                if (data[0]) {
                    $scope.stateLabel = data[0].authorityName;;
                    $scope.stateList = data[0].subdivisions;
                    $scope.supplierData.stateIdForAddress = (item.location.stateCode) ? item.location.stateCode : '';
                }
            }, function() {
                toaster.pop('error', "State", "server not responding");
            });
        }

        //		$scope.getCurrentSubscribesDisplayInEditSection('address',item.location.entityId,$scope.supplierIdInSearch);	

    }


    $scope.getCurrentSubscribesDisplayInEditSection = function(type, entityId, supplierId) {
        $scope.mainArray = [];
        $scope.loader = true;
        supplier.getcurrentSubscribersInSearcPage(type, entityId, supplierId).then(function(data) {
            $scope.subData = data.data;
            angular.forEach($scope.subData, function(value, key) {
                $scope.loader = true;
                supplier.getSubscriptionDetailsForIdFromSearch(value.id).then(function(data) {

                    var getSupplierPayTermLegal = data.data.subscription.subscriptionData.paymentTermId;
                    var getCommodityPayTermLegal = data.data.subscription.subscriptionData.commodityTier1Id;
                    var newgetSupplierPayTermLegalSubscriber;
                    var newgetCommodityLegalSubscriber;
                    //					if(getSupplierPayTermLegal){
                    //						supplier.getPayTermNameFromVal(getSupplierPayTermLegal).then(function(data){
                    //							newgetSupplierPayTermLegalSubscriber=data.name;
                    //						}, function() {
                    //							toaster.pop('error',"PayTerm Api fails", "PayTerm Api fails");    
                    //		 				});
                    //					}
                    //					if(getCommodityPayTermLegal){
                    //						supplier.getCommoditiesFamilyList().then(function(data){
                    //							angular.forEach(data, function(key, index) {
                    //								if(key.id==getCommodityPayTermLegal){
                    //									newgetCommodityLegalSubscriber = key.name;
                    //								}
                    //							});
                    //							
                    //					}, function() {
                    //						toaster.pop('error',"Commodity Api fails", "Commodity Api fails");   
                    //	 				});
                    //					}

                    angular.forEach(data.data.subscriberIds, function(subId, key) {
                        supplier.getBusinessSubListNewById(subId).then(function(data) {

                            $scope.mainArray.push({
                                "erpOrgName": data.erpOrgName,
                                "name": data.name,
                                "erpOrgNumber": data.erpOrgNumber,
                                "erpOrgName": data.erpOrgName,
                                "country": data.erpCountryCode,
                                "payTerm": getSupplierPayTermLegal,
                                "commodity": getCommodityPayTermLegal
                            })
                            $scope.loader = false;
                        }, function() {
                            $scope.loader = false;
                        });
                    });
                }, function() {
                    $scope.loader = false;
                });
                $scope.loader = false;
            });
            $scope.loader = false

        }, function() {
            $scope.loader = false;
        });


    }



    $scope.editBankSection = function(text, item) {
        $scope.loader = true;
        $scope.bankHeader = false;
        $scope.supplierData.furtherCreditForBank = item.useFurtherCreditTo;
        $scope.contentsFurtherCredit = item.useFurtherCreditTo;
        item.furtherCreditTo = (item.furtherCreditTo) ? item.furtherCreditTo : {};
        $scope.supplierData.bankCreditName = item.furtherCreditTo.bankName;
        $scope.supplierData.bankCreditNumber = item.furtherCreditTo.accountNumber;
        $scope.supplierData.bankCreditBenName = item.furtherCreditTo.beneficiaryName;
        $scope.editAddresses = angular.copy($scope.addresses);


        /*
	   if($scope.contentsFurtherCredit==true){
		   $scope.valueInFurtherCredit=true;
		   $scope.valueNotInFurtherCredit=false;
	   }
	   else if($scope.contentsFurtherCredit==false){
		   $scope.valueInFurtherCredit=false;
		   $scope.valueNotInFurtherCredit=true;
	   }


	   if(item.useFurtherCreditTo==false){
		   $scope.supplierData.furtherCreditForBank="false";
	   }
	   else{
		   $scope.supplierData.furtherCreditForBank="true";
	   }*/
        $scope.bankAccountsDetails = false;
        $scope.editForBankSection = true;
        $scope.paymentSubscribeSection = false;
        $scope.entityIdForBank = item.entityId;
        $scope.paymentSubscribeSection = false;
        //      supplier.editCreateWorkflow(text).then(function(data) {
        //    	  $scope.loader=false;
        //   	   if(data){
        //   	   $scope.instanceIdForSearch=data.instanceId;
        //   	   $cookieStore.put("searchInstanceId",data.instanceId);
        //   	   $scope.requestIdForSearch=data.requestId;
        //   	   $cookieStore.put("searchRequestId",data.requestId );
        //   	   $scope.taskIdForSearch=data.taskId;
        //   	   $cookieStore.put("searchTaskId",data.taskId);
        //   	   }
        //		    }, function() {
        //	        $scope.loader=false;
        //			});
        $scope.loader=false;
//        $scope.supplierData.bankCountryCodeForBank = (item.partyBankInfo.bankAddress) ? item.partyBankInfo.bankAddress.countryCode : '';
        $scope.supplierData.bankCountryCodeForBankOld = (item.partyBankInfo.bankAddress) ? item.partyBankInfo.bankAddress.countryCode : '';
        if($scope.supplierData.bankCountryCodeForBankOld){
        angular.forEach($scope.chooseCountries, function(key, index) {
            if (key.code == $scope.supplierData.bankCountryCodeForBankOld) {
            	$scope.supplierData.bankCountryCodeForBank = (key.id) ? key.id : '';
            }
        });
        }
        $scope.supplierData.bankCurrencyForBank = (item.partyBankInfo.accountCurrencyCode) ? item.partyBankInfo.accountCurrencyCode : '';
        $scope.supplierData.accountNameForBank = (item.partyAccountName) ? item.partyAccountName : '';
        $scope.supplierData.araRoutingForBank = (item.partyBankInfo.bankRoutingNumber) ? item.partyBankInfo.bankRoutingNumber : '';
        $scope.supplierData.accNumberForBank = (item.partyBankInfo.accountNumber) ? item.partyBankInfo.accountNumber : '';
        $scope.supplierData.remmitanceEmailForBank = (item.emailForRemittance) ? item.emailForRemittance : '';
        //		$scope.supplierData.furtherCreditForBank = (item.useFurtherCreditTo)?item.useFurtherCreditTo:'';

        //		$scope.getCurrentSubscribesDisplayInEditSection('bankAccount',item.entityId,$scope.supplierIdInSearch);
        $scope.editForBankSection = true;
    }
    $scope.paymentSubscribers = function() {
        $scope.paymentSubscribeSection = !$scope.paymentSubscribeSection;
    }
    $scope.editContactTab = function(text, item) {
        $scope.loader = true;
        $scope.contactSectionNew = false;
        $scope.contactSubscribeSection = false;
        $scope.contactNonEditSection = false;
        $scope.entityIdForContact = item.entityId
        $scope.editContactSection = true;
        //      supplier.editCreateWorkflow(text).then(function(data) {
        //    	  $scope.loader=false;
        //      	   if(data){
        //      	   $scope.instanceIdForSearch=data.instanceId;
        //      	   $cookieStore.put("searchInstanceId",data.instanceId);
        //      	   $scope.requestIdForSearch=data.requestId;
        //      	   $cookieStore.put("searchRequestId",data.requestId );
        //      	   $scope.taskIdForSearch=data.taskId;
        //      	   $cookieStore.put("searchTaskId",data.taskId);
        //      	   }
        //   		    }, function() {
        //   	        $scope.loader=false;
        //   			});

        $scope.supplierData.contactTypeForContact = (item.contactType) ? item.contactType : '';
        $scope.supplierData.firstNameForContact = (item.firstName) ? item.firstName : '';
        $scope.supplierData.lastNameForContact = (item.lastName) ? item.lastName : '';
        $scope.supplierData.emailForContact = (item.email) ? item.email : '';
        supplier.getPhoneCodes().then(function(data) {
            $scope.phoneCodes = data;
            angular.forEach($scope.phoneCodes, function(key, index) {
            	if(item.businessPhoneCountryPrefix){
                	$scope.loader=true;	
            	if(key.code==item.businessPhoneCountryPrefix){
            		$scope.supplierData.businessCodeForContact=key.phoneCode;
            	}
            	$scope.loader=false;
            }
            if(item.mobilePhoneCountryPrefix){
            	$scope.loader=true;
            	if(key.code==item.mobilePhoneCountryPrefix){
            		$scope.supplierData.mobileCodeForContact=key.phoneCode;
            	}
            	$scope.loader=false;
            }
            $scope.loader=false;	
            });
        }, function() {
        	$scope.loader=false;
            toaster.pop('error', "Phone list", "server not responding");
        });
        
        
        $scope.supplierData.businessCodeShortForContact = (item.businessPhoneCountryPrefix) ? item.businessPhoneCountryPrefix : '';
        $scope.supplierData.businessPhoneForContact = (item.businessPhoneNumber) ? item.businessPhoneNumber : '';
        $scope.supplierData.mobileCodeShortForContact = (item.mobilePhoneCountryPrefix) ? item.mobilePhoneCountryPrefix : '';
        $scope.supplierData.mobilePhoneForContact = (item.mobilePhoneNumber) ? item.mobilePhoneNumber : '';
        $scope.supplierData.preferredContactForContact = (item.preferredContact) ? item.preferredContact : '';
//        $scope.supplierData.businessCodeShortForContact = '';
//        $scope.supplierData.mobileCodeShortForContact = '';
        $scope.loader = false;
        //       $scope.getCurrentSubscribesDisplayInEditSection('contact',item.entityId,$scope.supplierIdInSearch);
        supplier.getPhoneCodes().then(function(data) {
            $scope.phoneCodes = data;
        }, function() {
            toaster.pop('error', "Phone list", "server not responding");
        });
    }
    $scope.editCertificationClick = function(text, item) {
        $scope.editCertification = true;
        $scope.editCertificationIcon = false;
        $scope.certificationNonEdit = false;

        //reset
        $scope.supplierInfo.isMemberOfGovernmentSupplyChain = false;
        $scope.supplierInfo.governmentSupplyChainProgram = '';
        $scope.supplierInfo.governmentSupplyChainCertNumber = '';
        $scope.supplierInfo.hasAnyISOCertifications = false;
        $scope.supplierInfo.isoCertificationNumber = '';
        $scope.supplierInfo.isoCertificationsCertDocId = '';
        $scope.supplierInfo.hasAnyOtherCertifications = false;
        $scope.supplierInfo.otherCertificationNumber = '';
        $scope.supplierInfo.otherCertificationsCertDocId = '';

        $scope.supplierInfo.blackOwned = false;
        $scope.supplierInfo.blackOwnedCertId = '';
        $scope.supplierInfo.blackOwnedCertificateExpirationDate = '';
        $scope.supplierInfo.blackOwnedScore = '';

        $scope.supplierInfo.alaskaNativeAndIndian = false;
        $scope.supplierInfo.alaskaNativeAndIndianCertId = '';
        $scope.supplierInfo.alaskaNativeAndIndianCertificateExpirationDate = '';
        $scope.supplierInfo.alaskaNativeAndIndianScore = '';

        $scope.supplierInfo.historicallyBlackColleges = false;
        $scope.supplierInfo.historicallyBlackCollegesCertId = '';
        $scope.supplierInfo.historicallyBlackCollegesCertificateExpirationDate = '';
        $scope.supplierInfo.historicallyBlackCollegesScore = '';

        $scope.supplierInfo.historicallyUnderutilizedBusiness = false;
        $scope.supplierInfo.historicallyUnderutilizedBusinessCertId = '';
        $scope.supplierInfo.historicallyUnderutilizedBusinessCertificateExpirationDate = '';
        $scope.supplierInfo.historicallyUnderutilizedBusinessScore = '';

        $scope.supplierInfo.lgbtBusiness = false;
        $scope.supplierInfo.lgbtBusinessCertId = '';
        $scope.supplierInfo.lgbtBusinessCertificateExpirationDate = '';
        $scope.supplierInfo.lgbtBusinessScore = '';

        $scope.supplierInfo.minorityBusiness = false;
        $scope.supplierInfo.minorityBusinessCertId = '';
        $scope.supplierInfo.minorityBusinessCertificateExpirationDate = '';
        $scope.supplierInfo.minorityBusinessScore = '';

        $scope.supplierInfo.serviceDisabledVeteranSmallBusiness = false;
        $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertId = '';
        $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertificateExpirationDate = '';
        $scope.supplierInfo.serviceDisabledVeteranSmallBusinessScore = '';

        $scope.supplierInfo.smallDisadvantagedBusiness = false;
        $scope.supplierInfo.smallDisadvantagedBusinessCertId = '';
        $scope.supplierInfo.smallDisadvantagedBusinessCertificateExpirationDate = '';
        $scope.supplierInfo.smallDisadvantagedBusinessScore = '';

        $scope.supplierInfo.veteranOwnedSmallBusiness = false;
        $scope.supplierInfo.veteranOwnedSmallBusinessCertId = '';
        $scope.supplierInfo.veteranOwnedSmallBusinessCertificateExpirationDate = '';
        $scope.supplierInfo.veteranOwnedSmallBusinessScore = '';

        $scope.supplierInfo.womenOwnedSmallBusiness = false;
        $scope.supplierInfo.womenOwnedSmallBusinessCertId = '';
        $scope.supplierInfo.womenOwnedSmallBusinessCertificateExpirationDate = '';
        $scope.supplierInfo.womenOwnedSmallBusinessScore = '';



        //      supplier.editCreateWorkflow(text).then(function(data) {
        //    	  $scope.loader=false;
        //      	   if(data){
        //			   $scope.instanceIdForSearch=data.instanceId;
        //			   $cookieStore.put("searchInstanceId",data.instanceId);
        //			   $scope.requestIdForSearch=data.requestId;
        //			   $cookieStore.put("searchRequestId",data.requestId );
        //			   $scope.taskIdForSearch=data.taskId;
        //			   $cookieStore.put("searchTaskId",data.taskId);
        //      	   }
        //   		}, function() {
        //   	        $scope.loader=false;
        //   		});

        angular.forEach($scope.supplierInfoDiversity, function(diversity, key) {
            if (diversity.type == 'BLACK_OWNED') {
                $scope.supplierInfo.blackOwned = diversity.apply;
                $scope.supplierInfo.blackOwnedCertId = diversity.docIds[0];
                $scope.supplierInfo.blackOwnedCertificateExpirationDate = diversity.certificateExpirationDate;
                $scope.supplierInfo.blackOwnedScore = diversity.score;
                /*$scope.fileDownload_blackOwnedCertId=true;
                var getId=document.getElementById('downloadUrlForFile_blackOwnedCertId');
                getId.href= constants.FILE_DOWNLOAD+$scope.supplierInfo.blackOwnedCertId;
                supplier.getlistFileUploaded($scope.supplierInfo.blackOwnedCertId).then(function(data) {
                	$scope.fileNameBlackOwnedCert=data.FileName;
                }, function(data) {});				
                */
            }
            if (diversity.type == 'ALASKA_NATIVE_CORP') {
                $scope.supplierInfo.alaskaNativeAndIndian = diversity.apply;
                $scope.supplierInfo.alaskaNativeAndIndianCertId = diversity.docIds[0];
                $scope.supplierInfo.alaskaNativeAndIndianCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.alaskaNativeAndIndianScore = diversity.score;
            }

            if (diversity.type == 'HISTORICALY_BLACK_CUMI') {
                $scope.supplierInfo.historicallyBlackColleges = diversity.apply;
                $scope.supplierInfo.historicallyBlackCollegesCertId = diversity.docIds[0];
                $scope.supplierInfo.historicallyBlackCollegesCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.historicallyBlackCollegesScore = diversity.score;
            }

            if (diversity.type == 'HUB_ZONE_B') {
                $scope.supplierInfo.historicallyUnderutilizedBusiness = diversity.apply;
                $scope.supplierInfo.historicallyUnderutilizedBusinessCertId = diversity.docIds[0];
                $scope.supplierInfo.historicallyUnderutilizedBusinessCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.historicallyUnderutilizedBusinessScore = diversity.score;
            }

            if (diversity.type == 'LGBT_BE') {
                $scope.supplierInfo.lgbtBusiness = diversity.apply;
                $scope.supplierInfo.lgbtBusinessCertId = diversity.docIds[0];
                $scope.supplierInfo.lgbtBusinessCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.lgbtBusinessScore = diversity.score;
            }

            if (diversity.type == 'MINORITY_BE') {
                $scope.supplierInfo.minorityBusiness = diversity.apply;
                $scope.supplierInfo.minorityBusinessCertId = diversity.docIds[0];
                $scope.supplierInfo.minorityBusinessCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.minorityBusinessScore = diversity.score;
            }

            if (diversity.type == 'SERVICE_DISABLED_VETERAN_OWNED_SB') {
                $scope.supplierInfo.serviceDisabledVeteranSmallBusiness = diversity.apply;
                $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertId = diversity.docIds[0];
                $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.serviceDisabledVeteranSmallBusinessScore = diversity.score;
            }

            if (diversity.type == 'DISADVANTAGED_SB') {
                $scope.supplierInfo.smallDisadvantagedBusiness = diversity.apply;
                $scope.supplierInfo.smallDisadvantagedBusinessCertId = diversity.docIds[0];
                $scope.supplierInfo.smallDisadvantagedBusinessCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.smallDisadvantagedBusinessScore = diversity.score;
            }

            if (diversity.type == 'VETERAN_OWNED_SB') {
                $scope.supplierInfo.veteranOwnedSmallBusiness = diversity.apply;
                $scope.supplierInfo.veteranOwnedSmallBusinessCertId = diversity.docIds[0];
                $scope.supplierInfo.veteranOwnedSmallBusinessCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.veteranOwnedSmallBusinessScore = diversity.score;
            }

            if (diversity.type == 'WOMEN_OWNED_SB') {
                $scope.supplierInfo.womenOwnedSmallBusiness = diversity.apply;
                $scope.supplierInfo.womenOwnedSmallBusinessCertId = diversity.docIds[0];
                $scope.supplierInfo.womenOwnedSmallBusinessCertificateExpirationDate = $filter('date')(diversity.certificateExpirationDate, 'yyyy-MM-dd');
                $scope.supplierInfo.womenOwnedSmallBusinessScore = diversity.score;
            }


        });



        angular.forEach($scope.certifications, function(certificate, key) {

            if (certificate.type == 'GOVT_SUPPLY_CHAIN') {
                $scope.supplierInfo.isMemberOfGovernmentSupplyChain = true;
                $scope.supplierInfo.governmentSupplyChainProgram = certificate.name;
                $scope.supplierInfo.governmentSupplyChainCertNumber = certificate.number
            }
            if (certificate.type == 'ISO') {
                $scope.supplierInfo.hasAnyISOCertifications = true;
                $scope.supplierInfo.isoCertificationNumber = certificate.number
                $scope.supplierInfo.isoCertificationsCertDocId = certificate.docIds[0];
            }


            if (certificate.type == 'OTHER') {
                $scope.supplierInfo.hasAnyOtherCertifications = true;
                $scope.supplierInfo.otherCertificationNumber = certificate.number
                $scope.supplierInfo.otherCertificationsCertDocId = certificate.docIds[0];
            }
        });

    }

    $scope.editCertificationCancel = function(panel) {
        $scope.loader = false;
        WorkFlow.cancelWorkflowV2($cookieStore.get("searchTaskId")).then(function(data) {
            toaster.pop('success', "WorkFlow cancelled successfully");
            $scope.loader = false;
            $scope.certificationNonEdit = true;
            $scope.editCertification = false;
            $scope.editCertificationIcon = true;
            $cookieStore.remove("searchTaskId");
            $scope.getDetailsWithStatus(panel);
        }, function(data) {
            toaster.pop('error', "WorkFlow cannot be cancelled", "Server not responding");
        });
    }

    $scope.supplierData = {}
    $scope.getDetailsWithStatus = function(status, text) {    	
        $scope.TaxRegFileCross = {};
        $scope.vatDocFile = {};
        $scope.TaxRegFileLegal = {};
        $scope.loader = true;
        if (text == "open") {
            $scope.editCompanyBtn = true;
            $scope.showEditCompanyPage = true;
            status.activeClass = "active";
            status.companyTab = true;
            status.addressTab = false;
            $scope.AddressSubscribeSection = false;
            status.paymentTab = false;
            status.contactTab = false;
            status.certificationTab = false;
            $scope.companyEditNonSection = true;
            $scope.certificationNonEdit = true;
            $scope.companyEditSection = false;
            $scope.editCertificationIcon = true;
        }
        // if (!(text == "open")) {
        //     return;
        // }
        $scope.loader = true;
        $scope.certifications = [];
        $scope.supplierInfoDiversity = [];
            $scope.supplierData.legalName = "";
            $scope.supplierData.supplierSpecialtyId = "";
            $scope.supplierData.countryCode = "";
            $scope.supplierData.taxClassification = "";
            $scope.supplierData.countryCode = "";
            //			$scope.addresses.orderFulfilmentAddress = [];
            //			$scope.addresses.manufacturingAddress = [];
            //			$scope.addresses.legalentity = [];
            $scope.bankAccounts = "";
            $scope.contacts = "";
            $scope.supplierInfoDiversity = "";
            $scope.dueDiligence = {};
            $scope.subscription = {};
            $scope.subscription.businessLevels = [];
            $scope.subscription.erpLevels = [];
            $scope.subscription.commoditiesList = [];
            $scope.paymentTermNameUpdated = "";
            $scope.address = (status.address) ? status.address : '';
            $scope.supplierIdInSearch = status.rootId;
            if(status.rootType=="supplier"){
            	$scope.newStatus=true
            }
            else{
            	$scope.newStatus=false
            }
            var obj={
            		"id":status.rootId,
            		"status":$scope.newStatus
            }

            supplier.getSupplierDetailsForSearch(obj).then(function(data) {            	
            	$scope.supplierIdNew=data.data.id;
                $scope.loader = false;
                $scope.supplierData.legalTax = (data.data.legalTax) ? data.data.legalTax : '';
                $scope.supplierData.legalName = (data.data.legalName) ? data.data.legalName : '';
                $scope.supplierData.localLanguageCode = (data.data.legalNameLocal) ? data.data.legalNameLocal : '';
                $scope.supplierData.countryCodeEditLegalEntityNew = (data.data.countryCode) ? data.data.countryCode : '';
                $scope.supplierData.taxNumber = (data.data.registrationId) ? data.data.registrationId : '';
                $scope.supplierData.taxClassificationName=(data.data.legalTax) ? data.data.legalTax.taxClassificationName : '';
                $scope.supplierData.ownerTaxClassificationName=(data.data.legalTax) ? data.data.legalTax.ownerTaxClassificationName : '';

                $scope.supplierData.supplierSpecialty = (data.data.supplierSpecialty) ? data.data.supplierSpecialty : '';
                $scope.supplierData.disRegardedEntity = (data.data.legalTax) ? data.data.legalTax.isDisregardedEntityForUS : '';
                $scope.supplierData.taxNumberLegalEntity = (data.data.legalTax) ? data.data.legalTax.taxIdentificationNumber : '';

                if (data.data.legalTax && data.data.legalTax.isDisregardedEntityForUS == true) {
                    $scope.supplierData.disregardEntLegalEntity = "true";
                    $rootScope.disRegardSection = "true";
                } else {
                    $scope.supplierData.disregardEntLegalEntity = "false";
                    $rootScope.disRegardSection = "false";
                }
                if (data.data.legalTax && data.data.legalTax.isLawOrMedicalOrHealthCare == true) {
                    $scope.supplierData.lawLegalEntity = "true";
                } else {
                    $scope.supplierData.lawLegalEntity = "false";
                }
                if (data.data.legalTax && data.data.legalTax.exemptFromWithholdingTax == true) {
                    $rootScope.exemptCheckBox = "true";
                    $scope.supplierData.withHoldingTaxRadio = "true";
                } else {
                    $rootScope.exemptCheckBox = "false";
                    $scope.supplierData.withHoldingTaxRadio = "false";
                }


                $scope.supplierData.ownerLegalNameLegalEntity = (data.data.legalTax) ? data.data.legalTax.ownerLegalname : '';
                $scope.supplierData.ownerCountry = (data.data.legalTax) ? data.data.legalTax.ownerCountryCode : '';
                if ($scope.supplierData.ownerCountry != null) {
                    angular.forEach($scope.chooseCountries, function(key, index) {
                        if (key.name == $scope.supplierData.ownerCountry) {
                            $scope.ownerCountryCodeCheck = (key.code) ? key.code : '';
                            supplier.withHoldingTaxTypes($scope.ownerCountryCodeCheck).then(function(data) {
                                $scope.loader = false;
                                $scope.withHoldingTypesForOwner = data;
                            }, function(data) {
                                $scope.loader = false;
                                toaster.pop('error', "Tax Types Api Server Not Responding");
                            });
                        }
                    });
                    $scope.flagValue = true;
                } else {
                    angular.forEach($scope.chooseCountries, function(key, index) {
                        if (key.name == $scope.supplierData.ownerCountry) {
                            $scope.ownerCountryCodeCheck = (key.code) ? key.code : '';
                            supplier.withHoldingTaxTypes($scope.ownerCountryCodeCheck).then(function(data) {
                                $scope.loader = false;
                                $scope.withHoldingTypesForOwner = data;
                            }, function(data) {
                                $scope.loader = false;
                                toaster.pop('error', "Tax Types Api Server Not Responding");
                            });
                        }
                    });
                    $scope.flagValue = false;
                }
                $scope.supplierData.ownerTaxIdNoLegalEntity = (data.data.legalTax) ? data.data.legalTax.ownerTaxIdentificationNumber : '';
                $scope.supplierData.ownerCountryLegalEntity = (data.data.legalTax) ? data.data.legalTax.ownerCountryCode : '';
                angular.forEach($scope.agentTypes, function(key, index) {
                    if (key.id == $scope.supplierData.supplierSpecialty) {
                        $scope.supplierData.supplierSpecialtyId = (key.name) ? key.name : '';
                    }
                });
                $scope.supplierData.countryCodeEdit = data.data.countryCode;
                if (data.data.countryCode != "" || data.data.countryCode != undefined) {
                    angular.forEach($scope.chooseCountries, function(key, index) {
                        if (key.code == data.data.countryCode) {
                            $scope.supplierData.countryCode = (key.name) ? key.name : ''
                        }
                    });
                }
                $scope.supplierData.TaxHoldingEdit = (data.data.taxClassification) ? data.data.taxClassification : '';
                //			    supplier.getWithHoldingTaxTypeById(data.data.taxClassification).then(function(data){
                //		    	$scope.supplierData.taxClassification = (data.name)?data.name:'';
                //			    }, function() {
                //			        $scope.loader=false;
                //					});
                //					

                $scope.supplierData.w9Document = (data.data.w9DocId) ? data.data.w9DocId : '';
                $scope.supplierData.IsDisregarded = '';
                $scope.supplierData.ownerName = '';
                $scope.supplierData.ownerCountry = '';
                $scope.supplierData.ownerTaxClassify = '';
                $scope.supplierData.ownerTaxReg = '';
                $scope.valtlist = (data.data.vats) ? data.data.vats : [];
                
                if($scope.valtlist.length>0){
                	$scope.vatFlag = true;
                }
                else{
                	$scope.vatFlag = false;
                }
                $scope.crossBorderList = (data.data.crossBorderTaxes) ? data.data.crossBorderTaxes : [];
                if($scope.crossBorderList.length>0){
                	$scope.crossFlag=true;
                }
                else{
                	$scope.crossFlag=false;
                }
                $scope.bankAccounts = (data.data.bankAccounts) ? data.data.bankAccounts : [];
                angular.forEach($scope.bankAccounts, function(value, key) {
                	$scope.bankCurrencyCode=value.partyBankInfo.accountCurrencyCode;
//                		supplier.getCurrencyListById($scope.bankCurrencyCode).then(function(data) {
//                			value.partyBankInfo.accountCurrencyCode=data.currencyCode;
//                		});
                });
                $scope.contacts = (data.data.contacts) ? data.data.contacts : [];
                $scope.certifications = (data.data.certifications) ? data.data.certifications : [];
                angular.forEach($scope.certifications, function(certificate, key) {
                    //certificate.docIds = ['502602923-20161130074750-iso', '502602923-20161130074750-iso']; //REMOVE
                    certificate.fileName = [];
                    angular.forEach(certificate.docIds, function(fValue, fKey) {
                        supplier.getlistFileUploaded(fValue).then(function(data) {
                            certificate.fileName.push({
                                name: data.FileName,
                                link: constants.FILE_DOWNLOAD + fValue
                            });
                        }, function(data) {});
                    });

                    if (certificate.type == 'GOVT_SUPPLY_CHAIN') {
                        certificate.uiName = "Are you a member of a government operated supply chain security certification program (e.g. CTPAT/Canada PIP/AEO)?";
                    }
                    if (certificate.type == 'ISO') {
                        certificate.uiName = "Do you have any ISO Certifications?";
                    }
                    if (certificate.type == 'OTHER') {
                        certificate.uiName = "Do you have any other certifications you wish to provide?";
                    }
                });
                $scope.supplierInfoDiversity = (data.data.diversities) ? data.data.diversities : [];

                angular.forEach($scope.supplierInfoDiversity, function(diversity, key) {

                    var idArray = $filter('filter')($scope.divrsityMap, {
                        key: diversity.type
                    });
                    if (idArray[0]) {
                        if (idArray[0].value) {
                            diversity.label = idArray[0].value;
                        }
                    }

                    diversity.fileName = [];

                    //diversity.docIds = ['502602923-20161130074750-iso', '502602923-20161130074750-iso']; //REMOVE
                    angular.forEach(diversity.docIds, function(fValue, fKey) {
                        supplier.getlistFileUploaded(fValue).then(function(data) {
                            diversity.fileName.push({
                                name: data.FileName,
                                link: constants.FILE_DOWNLOAD + fValue
                            });
                        }, function(data) {});
                    });

                })
                $scope.addresses = (data.data.addresses) ? data.data.addresses : [];

                $scope.entityIdForAddress = data.data.addresses[0].entityId

                angular.forEach($scope.addresses, function(address, index) {
                    address.supplierNumber = '';
                    var idArray = $filter('filter')(address.alternateIds, {
                        type: "SCID"
                    });
                    if (idArray[0]) {
                        if (idArray[0].value) {
                            address.supplierNumber = idArray[0].value;
                        }
                    }
                    if (address.addressTypes.indexOf("ORDER_FULLFILLING") != -1) {
                        if (!$scope.addresses.orderFulfilmentAddress) {
                            $scope.addresses.orderFulfilmentAddress = [];
                        }
                        angular.forEach($scope.chooseCountries, function(key, index) {
                            if (key.id == address.location.countryCode) {
                                supplier.getStatesList(key.code).then(function(data) {
                                    angular.forEach(data.subdivisions, function(key, index) {
                                        if (key.id == address.location.stateCode) {
                                            $scope.orderStateName = key.subdivisionName;
                                        }
                                    });
                                }, function() {
                                    toaster.pop('error', "States list", "server not responding");
                                });
                            }
                        });
                        address.location.entityId = address.entityId;
                        $scope.addresses.orderFulfilmentAddress.push(address.location);
                    }
                    if (address.addressTypes.indexOf("MANUFACTURING") != -1) {
                        if (!$scope.addresses.manufacturingAddress) {
                            $scope.addresses.manufacturingAddress = [];
                        }
                        angular.forEach($scope.chooseCountries, function(key, index) {
                            if (key.id == address.location.countryCode) {
                                supplier.getStatesList(key.code).then(function(data) {
                                    angular.forEach(data.subdivisions, function(key, index) {
                                        if (key.id == address.location.stateCode) {
                                            $scope.manuStateName = key.subdivisionName;
                                        }
                                    });
                                }, function() {
                                    toaster.pop('error', "States list", "server not responding");
                                });
                            }
                        });
                        address.location.entityId = address.entityId;
                        $scope.addresses.manufacturingAddress.push(address.location);
                    }
                    if (address.addressTypes.indexOf("SHIPPING") != -1) {
                        if (!$scope.addresses.shippingAddress) {
                            $scope.addresses.shippingAddress = [];
                        }
                        angular.forEach($scope.chooseCountries, function(key, index) {
                            if (key.id == address.location.countryCode) {
                                supplier.getStatesList(key.code).then(function(data) {
                                    angular.forEach(data.subdivisions, function(key, index) {
                                        if (key.id == address.location.stateCode) {
                                            $scope.shipStateName = key.subdivisionName;
                                        }
                                    });
                                }, function() {
                                    toaster.pop('error', "States list", "server not responding");
                                });
                            }
                        });
                        address.location.entityId = address.entityId;
                        $scope.addresses.shippingAddress.push(address.location);
                    }

                    if (address.addressTypes.indexOf("LEGAL") != -1) {
                        if (!$scope.addresses.legalentity) {
                            $scope.addresses.legalentity = [];
                        }
                        $scope.legalAddresslocation = (address.location) ? address.location : '';
                        $scope.entityCompanyInfo = (address.entityId) ? address.entityId : '';
                        $scope.supplierData.addressLine1 = (address.location) ? address.location.addressLine1 : '';
                        $scope.supplierData.addressLine2 = (address.location) ? address.location.addressLine2 : '';
                        $scope.supplierData.addressLine3 = (address.location) ? address.location.addressLine3 : '';
                        $scope.supplierData.addressLine4 = (address.location) ? address.location.addressLine4 : '';
                        $scope.supplierData.legalCity = (address.location) ? address.location.cityName : '';
                        $scope.supplierData.postalCode = (address.location) ? address.location.postalCode : '';

                        $scope.supplierData.legalCountry = (address.location) ? address.location.countryCode : '';
                        //						$scope.supplierData.countryCodeEditLegalEntity = (address.location)?address.location.countryCode:'';

                        angular.forEach($scope.chooseCountries, function(key, index) {
                            if (key.id == address.location.countryCode) {
                                supplier.getStatesList(key.code).then(function(data) {
                                    angular.forEach(data.subdivisions, function(key, index) {
                                        if (key.id == address.location.stateCode) {
                                            $scope.shipStateName = key.subdivisionName;
                                        }
                                    });
                                }, function() {
                                    toaster.pop('error', "States list", "server not responding");
                                });
                            }
                        });
                        address.location.entityId = address.entityId;
                        $scope.addresses.legalentity.push(address.location);
                    }

                    if (address.addressTypes.length == 0) {
                        if (!$scope.addresses.addresswithNoType) {
                            $scope.addresses.addresswithNoType = [];
                        }
                        angular.forEach($scope.chooseCountries, function(key, index) {
                            if (key.id == address.location.countryCode) {
                                supplier.getStatesList(key.code).then(function(data) {
                                    angular.forEach(data.subdivisions, function(key, index) {
                                        if (key.id == address.location.stateCode) {
                                            $scope.commonStateName = key.subdivisionName;
                                        }
                                    });
                                }, function() {
                                    toaster.pop('error', "States list", "server not responding");
                                });
                            }
                        });
                        address.location.entityId = address.entityId;
                        $scope.addresses.addresswithNoType.push(address.location);
                    }
                });



                $scope.dueDiligence = (data.data.dueDiligence) ? (data.data.dueDiligence) : {};
                $scope.subscription = (data.data.subscription) ? (data.data.subscription) : {};
                if (data.data.subscription != undefined) {
                    /*if(data.data.subscription.paymentTermsId!=""||data.data.subscription.paymentTermsId!=""){
		        	supplier.getPaymentTermsById(data.data.subscription.paymentTermsId).then(function(data) {
                        if(data.name){
                        	$scope.paymentTermNameUpdated=data.name;
                        }
                        else{
                        	$scope.paymentTermNameUpdated=data.data.subscription.paymentTermsId;
                        }
	        		}, function() {
	        			toaster.pop('error', "Payment Term", "server not responding");
	        		});
		        }
		        else{
		        	$scope.paymentTermNameUpdated="";
		        }*/
                }

                $scope.subscription.businessLevels = (data.data.subscription) ? (data.data.subscription.businessLevels) : [];
                $scope.subscription.commoditiesList = (data.data.subscription) ? (data.data.subscription.commodities) : [];
                $scope.subscription.erpLevels = (data.data.subscription) ? (data.data.subscription.erpId) : [];
                if ($scope.subscription.businessLevels != "" || $scope.subscription.businessLevels != undefined) {
                    angular.forEach($scope.subscription.businessLevels, function(value, index) {
                        $scope.businessLevel = [];
                        supplier.getbusinessLevelsNameFromID(value).then(function(data) {
                            //$scope.businessLevelsArray.push(data.name)
                            $scope.businessLevel[index] = data.name;
                        }, function() {
                            toaster.pop('error', "Business Names list", "server not responding");
                        });
                    });
                }
                if ($scope.subscription.commoditiesList != "" || $scope.subscription.commoditiesList != undefined && $scope.subscription.commoditiesList.length > 0) {
                    angular.forEach($scope.subscription.commoditiesList, function(value, index) {
                        $scope.commoditiesLevelsArray = []
                        supplier.getcommodityValueFromId(value).then(function(data) {
                            $scope.commoditiesLevelsArray.push({
                                "name": data.name
                            })
                            $scope.firstCommodityValue = data[0].name;
                        }, function() {
                            toaster.pop('error', "Business Names list", "server not responding");
                        });
                    });
                } else {
                    $scope.firstCommodityValue = '';
                }
                $scope.firstCommodityValue = data.data.commodityTier1;
                if ($scope.subscription.erpLevels.length > 0 && $scope.subscription.erpLevels != undefined) {
                    angular.forEach($scope.subscription.erpLevels, function(value, index) {
                        supplier.getSubscriberLabel(value).then(function(data) {
                            $scope.businessLevel4 = data;
                        }, function() {
                            toaster.pop('error', "Business Level 4", "server not responding");
                        });
                    });
                } else {
                    $scope.businessLevel4 = '';
                }
                $scope.loader = false;
            }, function(data) {
                $scope.loader = false;
                toaster.pop('error', "Supplier API", "server not responding");
            });
        } 



    $scope.getCurrentSubscribers = function(type, entityId, item) {
        //		$scope.AddressSubscribeSection=true;
        $scope.editAddressSection = false;
        $scope.paymentSubscribeSection = true;
        $scope.editForBankSection = false;
        //		$scope.contactSubscribeSection=true;
        $scope.editContactSection = false;
        $scope.mainLegalArray = [];
        $scope.loader = true;
        $scope.entType = type;
        if (type == "address") {
            angular.forEach($scope.addresses, function(value, key) {
                if (!angular.equals(value, item)) {
                    value.AddressSubscribeSection = false
                }

            });
            item.AddressSubscribeSection = !item.AddressSubscribeSection;
        }
        if (type == "bankAccount") {
            angular.forEach($scope.bankAccounts, function(value, key) {
                if (!angular.equals(value, item)) {
                    value.paymentSubscribeSection = false
                }
            });

            item.paymentSubscribeSection = !item.paymentSubscribeSection;

        }

        if (type == "contact") {
            angular.forEach($scope.contacts, function(value, key) {
                if (!angular.equals(value, item)) {
                    value.contactSubscribeSection = false
                }
            });
            item.contactSubscribeSection = !item.contactSubscribeSection;

        }


        supplier.getcurrentSubscribersInSearcPage($scope.entType, entityId, $scope.supplierIdInSearch).then(function(data) {


            $scope.loader = true;
            $scope.subData = data.data;
            angular.forEach($scope.subData, function(value, key) {
                $scope.loader = true;
                supplier.getSubscriptionDetailsForIdFromSearch(value.id).then(function(data) {

                    var getSupplierPayTermLegal = data.data.subscription.subscriptionData.paymentTermId;
                    var getCommodityPayTermLegal = data.data.subscription.subscriptionData.commodityTier1Id;
                    var newgetSupplierPayTermLegal;
                    var newgetCommodityLegal;
                    //					if(getSupplierPayTermLegal){
                    //						supplier.getPayTermNameFromVal(getSupplierPayTermLegal).then(function(data){
                    //							newgetSupplierPayTermLegal=data.name;
                    //						}, function() {
                    //							toaster.pop('error',"PayTerm Api fails", "PayTerm Api fails");    
                    //		 				});
                    //					}
                    //					if(getCommodityPayTermLegal){
                    //						supplier.getCommoditiesFamilyList().then(function(data){
                    //							angular.forEach(data, function(key, index) {
                    //								if(key.id==getCommodityPayTermLegal){
                    //									newgetCommodityLegal = key.name;
                    //								}
                    //							});
                    //							
                    //					}, function() {
                    //						toaster.pop('error',"Commodity Api fails", "Commodity Api fails");   
                    //	 				});
                    //					}
                    angular.forEach(data.data.subscriberIds, function(subId, key) {
                        supplier.getBusinessSubListNewById(subId).then(function(data) {

                            $scope.mainLegalArray.push({
                                "erpOrgName": data.erpOrgName,
                                "name": data.name,
                                "erpOrgNumber": data.erpOrgNumber,
                                "erpOrgName": data.erpOrgName,
                                "country": data.erpCountryCode,
                                "payTerm": getSupplierPayTermLegal,
                                "commodity": getCommodityPayTermLegal
                            })

                        }, function() {

                        });
                    });




                }, function() {
                    $scope.loader = false;
                });
                $scope.loader = false;
            });
            $scope.loader = false

        }, function() {
            $scope.loader = false;
        });
    }



    $scope.getCurrentSubscribersForCommodity = function(text, item) {

        $scope.loader = true;

        supplier.getCommoditiesFromSupplierInSearch($scope.supplierIdInSearch).then(function(data) {
            $scope.loader = false;
            $scope.commoditySearchTab = data.data;
            angular.forEach($scope.commoditySearchTab, function(value, key) {
                if (!angular.equals(value, item)) {
                    value.commoditySearchSection = false;
                }
            });
        }, function() {
            $scope.loader = false;
        });
        
        

        item.commoditySearchSection = !item.commoditySearchSection;
        supplier.getcurrentSubscribersForCommodityFromSearch(text, item, $scope.supplierIdInSearch).then(function(data) {
            debugger
            $scope.loader = false;
            if (data.data != "" && data.data != undefined && text == "address") {

                $scope.getNewSubscribersForaddress = data.data;
                // $scope.commodityLevelAddress=true;
            }
            if (data.data != "" && data.data != undefined && text == "commodity") {

                $scope.commodityGetNewSubscribersForSearch = data.data;
                // $scope.commodityLevelAddress=true;
            } else {
                $scope.commodityGetNewSubscribersForSearch = "";
            }


        }, function() {
            $scope.loader = false;
        });
    }

    /******** BASIC SAVE *************/
    $scope.saveChangesForTab = function(supplierData, text, panel, textHeader) {
        supplier.editCreateWorkflow(textHeader).then(function(data) {
            $scope.loader = false;
            if (data) {
                $scope.instanceIdForSearch = data.instanceId;
                $cookieStore.put("searchInstanceId", data.instanceId);
                $scope.requestIdForSearch = data.requestId;
                $cookieStore.put("searchRequestId", data.requestId);
                $scope.taskIdForSearch = data.taskId;
                $cookieStore.put("searchTaskId", data.taskId);
                $scope.newVatArray = [];
                if (text == "companyEdit") {
                	
                    if ($scope.legalTaxRule == "" || $scope.legalTaxRule == undefined) {
                        supplier.checkTaxApiValidationForSearchPage(supplierData, $scope.countryOfIncorporation).then(function(data) {
                            if (data.data == true) {
                                $scope.legalTaxRule = true;

                            } else {
                                $scope.legalTaxRule = false;
                                toaster.pop('error', "Tax Validation api fails");
                                return
                            }
                        });
                    } else if ($scope.legalTaxRule == false) {
                        toaster.pop('error', "Tax Validation api", "Tax Validation api fails");
                        $scope.loader = false;
                        return
                    } else {}
                    
                    if(supplierData.vatCountryCompanyInfo!="" &&supplierData.vatTaxAuthorityCompanyInfo!="" && supplierData.vatTaxIdCompanyInfo!="" ){
                    	  supplier.checkVatTaxApiValidationForSearch(supplierData).then(function(data) {
                              $scope.loader = false;
                              if (data.data == "true") {
                                     $scope.valtlist.push({
                                  	countryId: supplierData.vatCountryCompanyInfo,
                                      taxAuthorityId: supplierData.vatTaxAuthorityCompanyInfo,
                                      docId: ($scope.vatDocFile.files) ? $scope.vatDocFile.files[0].id : '',
                                      taxNumber: supplierData.vatTaxIdCompanyInfo,
                                      name:($scope.vatDocFile.files) ? $scope.vatDocFile.files[0].name : '',
                                  })  
                              }
                              else {
                            	  toaster.pop('error', "Tax Validation api For Vat Section", "Tax Validation api fails"); 
                              }
                    	  });
                    }
                    
                  if(supplierData.crossCountryCompanyInfo!="" && supplierData.crossTaxRegNo!=""){
                      $scope.crossBorderList.push({
                          countryCode: supplierData.crossCountryCompanyInfo,
                          providedProductId: supplierData.types,
                          taxRegistrationNumber: $scope.supplierData.crossTaxRegNo,
                          documentId: ($scope.TaxRegFileCross.files) ? $scope.TaxRegFileCross.files[0].id : '',
                          w8DocId: '',
                          w8BenDocId: '',
                          form8233DocId: '',
                          exemptFromWithholdingTax: $scope.supplierData.withHoldingCrossTax,
                          exemptDocumentId: ($scope.TaxExemptFile.files) ? $scope.TaxExemptFile.files[0].id : ''
                      })
                  }  
                    
                    
                    
                    if (supplierData.disregardEntLegalEntity == "true" && $scope.legalTaxRuleOwner == true) {

                    } else if (supplierData.disregardEntLegalEntity == "true" && $scope.legalTaxRuleOwner == false) {
                        toaster.pop('error', "Tax Validation api For Owners Section", "Tax Validation api fails");
                        $scope.loader = false;
                        return
                    } else if (supplierData.disregardEntLegalEntity == "true" && $scope.legalTaxRuleOwner == "" || $scope.legalTaxRuleOwner == undefined) {
                        $scope.loader = true;
                        angular.forEach($scope.chooseCountries, function(value, key) {
                            if (value.name == supplierData.ownerCountryLegalEntity) {
                                $scope.countryNameForOwner = value.code;
                            }
                        });

                        supplier.checkTaxApiValidationForSearchPageForOwner($scope.countryNameForOwner, supplierData).then(function(data) {
                            $scope.loader = false;
                            if (data.data == true) {
                                $scope.legalTaxRuleOwner = true;
                            } else {
                                $scope.legalTaxRuleOwner = false;
                                toaster.pop('error', "Tax Validation api fails");
                                return
                            }
                        }, function() {
                            $scope.loader = false;
                            toaster.pop('error', "Tax Validation api", "Tax Validation api fails");
                            return
                        });
                    } else {}

                    if ($scope.legalTaxRule == false) {
                        toaster.pop('error', "Tax Validation api", "Tax Validation api fails");
                        return
                    }
                    if ($scope.legalTaxRuleOwner == false && $scope.dataUIVisibility.legalTax.ownerCountry.enabled == true) {
                        toaster.pop('error', "Tax Validation for Owners api", "Tax Validation api fails");
                        return
                    }
                    $scope.newVatlistArr=[];
                    if($scope.valtlist.length>0){
                    	 angular.forEach($scope.valtlist, function(value, key) {
                    		 $scope.newVatlistArr.push({"countryId":value.countryCode,"taxAuthorityId":value.taxAuthority,"taxNumber":value.taxRegistrationNumber,"documentId":value.name})		 
                    	 });
                    }

                    var obj = {
                        "partyId": $scope.supplierIdInSearch,
                        "supplier": {
                        	"legalName":supplierData.legalName,
                            "addresses": [{
                                "entityId": $scope.entityCompanyInfo,
                                "location": {
                                    "addressLine1": supplierData.addressLine1,
                                    "addressLine2": supplierData.addressLine2,
                                    "addressLine3": supplierData.addressLine3,
                                    "addressLine4": supplierData.addressLine4,
                                    "cityName": supplierData.legalCity,
                                    "postalCode": supplierData.postalCode,
                                    "stateId": supplierData.legalState,
                                }
                            }],
                            "legalTax": {
                                "documentId": ($scope.companyFile.files) ? $scope.companyFile.files[0].id : '',
                                "exemptDocumentId": "",
                                "exemptFromWithholdingTax": supplierData.withHoldingTaxRadio,
                                "isDisregardedEntityForUS": supplierData.disregardEntLegalEntity,
                                "isLawOrMedicalOrHealthCare": supplierData.lawLegalEntity,
                                "ownerLegalname": supplierData.ownerLegalNameLegalEntity,
                                "ownerTaxClassificationId": $scope.taxClassifyValidationForOwner, //supplierData.ownerTaxClassifyLegalEntity,
                                "ownerTaxRegistrationNumber": supplierData.ownerTaxIdNoLegalEntity,
                                "taxClassificationId": $rootScope.taxClassifyValidation, //supplierData.taxClassificationLegalEntity  ,
                                "ownerCountry": $scope.countryNameForOwner,
                                "taxRegistrationNumber": supplierData.taxNumberLegalEntity,
                                "w9DocId": ($scope.companyFile.files) ? $scope.companyFile.files[0].id : '',
                            },
                            "vat": $scope.newVatlistArr
//                            "crossBorderTaxes": $scope.crossBorderList
                        }
                    };
                    saveAndCompleteWorkFlowSearchTab(obj, text, panel);
                } else if (text == "AddressTab") {
                    swal({
                            title: "Are you sure you want to replace this existing address rather than ADD a new one?",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#8cc63f",
                            confirmButtonText: "Confirm",
                            cancelButtonText: "Cancel",
                            closeOnConfirm: true,
                            closeOnCancel: true
                        },
                        function(isConfirm) {
                            if (isConfirm) {
                                swal("Address is updated successfully.", "", "success");
                                console.log("SAVE-ADDRESS-PARAMS", supplierData);
                                obj = {
                                    "partyId": $scope.supplierIdInSearch,
                                    "supplier": {
                                        "addresses": [{
                                            "entityId": $scope.addressEntityId,
                                            "location": {
                                                "addressLine1": supplierData.addressLine1ForAddress,
                                                "addressLine2": supplierData.addressLine2ForAddress,
                                                "addressLine3": supplierData.addressLine3ForAddress,
                                                "addressLine4": supplierData.addressLine4ForAddress,
                                                "cityName": supplierData.cityNameForAddress,
                                                "postalCode": supplierData.postalCodeForAddress,
                                                "stateId": supplierData.stateIdForAddress,
                                            }
                                        }]
                                    }
                                }
                                saveAndCompleteWorkFlowSearchTab(obj, text, panel);
                            } else {}
                        })
                } else if (text == "paymentTab") {

                    var assocFlag = false;
                    var linkAddresses = []
                    angular.forEach($scope.editAddresses, function(address, key) {
                        if (address.assocAddress) {
                            linkAddresses.push(address.entityId);
                            assocFlag = true;
                        }
                    });
                    if (assocFlag == false) {
                        toaster.pop('error', "", "Please choose atleast one associate address for each bank");
                        return;
                    }
                    console.log("SAVE-PAYMENT-PARAMS", supplierData);
                    var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if (supplierData.remmitanceEmailForBank && !regEx.test(supplierData.remmitanceEmailForBank)) {
                        toaster.pop('error', "Please enter valid remittance email");
                        return;
                    }

                    obj = {
                        "partyId": $scope.supplierIdInSearch,
                        "supplier": {
                            "banks": [{
                                "entityId": $scope.entityIdForBank,
                                "partyAccountName": supplierData.accountNameForBank,
                                "partyBankInfo": {
                                    "remittanceEmailAddress": supplierData.remmitanceEmailForBank,
                                    "addresses": linkAddresses
                                },
                                "useFurtherCreditTo": false,
                            }]
                        }
                    }
                    saveAndCompleteWorkFlowSearchTab(obj, text, panel);
                } else if (text == "contactTab") {
                    console.log("SAVE-CONTACT-PARAMS", supplierData);
                    obj = {
                        "partyId": $scope.supplierIdInSearch,
                        "supplier": {
                            "contacts": [{
                                //"businessPhoneCountryId": supplierData.businessCodeForContact,
                                "businessPhoneCountryId": (supplierData.businessCodeShortForContact)?supplierData.businessCodeShortForContact:null,
                                "businessPhoneNumber": (supplierData.businessPhoneForContact)?supplierData.businessPhoneForContact:null,
                                "email": supplierData.emailForContact,
                                "entityId": $scope.entityIdForContact,
                                "firstName": supplierData.firstNameForContact,
                                "lastName": supplierData.lastNameForContact,
                                //"mobilePhoneCountryId": supplierData.mobileCodeForContact,
                                "mobilePhoneCountryId": (supplierData.mobileCodeShortForContact)?supplierData.mobileCodeShortForContact:null,
                                "mobilePhoneNumber": (supplierData.mobilePhoneForContact)?supplierData.mobilePhoneForContact:null,
                                "preferredContact": null
                            }]
                        }
                    }
                    saveAndCompleteWorkFlowSearchTab(obj, text, panel);
                } else if (text == "certificationTab") {
                    console.log("SAVE_CERTIFICATION-PARAMS", supplierData);
                    obj = {
                        "partyId": $scope.supplierIdInSearch,
                        "supplier": {
                            "diversity": {
                                alaskaNativeAndIndian: {
                                    apply: $scope.supplierInfo.alaskaNativeAndIndian,
                                    certificateDocumentId: ($scope.alaskaNativeAndIndianFile.files) ? $scope.alaskaNativeAndIndianFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.alaskaNativeAndIndianCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.alaskaNativeAndIndianScore
                                },
                                blackOwned: {
                                    apply: $scope.supplierInfo.blackOwned,
                                    certificateDocumentId: ($scope.blackOwnedFile.files) ? $scope.blackOwnedFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.blackOwnedCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.blackOwnedScore
                                },
                                historicallyBlackColleges: {
                                    apply: $scope.supplierInfo.historicallyBlackColleges,
                                    certificateDocumentId: ($scope.historicallyBlackFile.files) ? $scope.historicallyBlackFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.historicallyBlackCollegesCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.historicallyBlackCollegesScore
                                },
                                historicallyUnderutilizedBusiness: {
                                    apply: $scope.supplierInfo.historicallyUnderutilizedBusiness,
                                    certificateDocumentId: ($scope.historicallyUnderutilizedFile.files) ? $scope.historicallyUnderutilizedFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.historicallyUnderutilizedBusinessCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.historicallyUnderutilizedBusinessScore
                                },
                                lgbtBusiness: {
                                    apply: $scope.supplierInfo.lgbtBusiness,
                                    certificateDocumentId: ($scope.lgbtBusinessFile.files) ? $scope.lgbtBusinessFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.lgbtBusinessCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.lgbtBusinessScore
                                },
                                minorityBusiness: {
                                    apply: $scope.supplierInfo.minorityBusiness,
                                    certificateDocumentId: ($scope.minorityBusinessFile.files) ? $scope.minorityBusinessFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.minorityBusinessCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.minorityBusinessScore
                                },
                                serviceDisabledVeteranSmallBusiness: {
                                    apply: $scope.supplierInfo.serviceDisabledVeteranSmallBusiness,
                                    certificateDocumentId: ($scope.serviceDisabledVeteranFile.files) ? $scope.serviceDisabledVeteranFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.serviceDisabledVeteranSmallBusinessCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.serviceDisabledVeteranSmallBusinessScore
                                },
                                smallDisadvantagedBusiness: {
                                    apply: $scope.supplierInfo.smallDisadvantagedBusiness,
                                    certificateDocumentId: ($scope.smallDisadvantagedFile.files) ? $scope.smallDisadvantagedFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.smallDisadvantagedBusinessCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.smallDisadvantagedBusinessScore
                                },
                                veteranOwnedSmallBusiness: {
                                    apply: $scope.supplierInfo.veteranOwnedSmallBusiness,
                                    certificateDocumentId: ($scope.veteranOwnedSmallBusinessFile.files) ? $scope.veteranOwnedSmallBusinessFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.veteranOwnedSmallBusinessCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.veteranOwnedSmallBusinessScore
                                },
                                womenOwnedSmallBusiness: {
                                    apply: $scope.supplierInfo.womenOwnedSmallBusiness,
                                    certificateDocumentId: ($scope.womenOwnedSmallBusinessFile.files) ? $scope.womenOwnedSmallBusinessFile.files[0].id : '',
                                    certificateExpirationDate: $scope.supplierInfo.womenOwnedSmallBusinessCertificateExpirationDate || 0,
                                    score: $scope.supplierInfo.womenOwnedSmallBusinessScore
                                }
                            },
                            "certifications": {
                                "isMemberOfGovernmentSupplyChain": $scope.supplierInfo.isMemberOfGovernmentSupplyChain,
                                "governmentSupplyChainProgram": $scope.supplierInfo.governmentSupplyChainProgram,
                                "governmentSupplyChainCertNumber": $scope.supplierInfo.governmentSupplyChainCertNumber,
                                "hasAnyISOCertifications": $scope.supplierInfo.hasAnyISOCertifications,
                                "isoCertificationNumber": $scope.supplierInfo.isoCertificationNumber,
                                "isoCertificationsCertDocId": ($scope.isoFile.files) ? $scope.isoFile.files[0].id : '',
                                "hasAnyOtherCertifications": $scope.supplierInfo.hasAnyOtherCertifications,
                                "otherCertificationNumber": $scope.supplierInfo.otherCertificationNumber,
                                "otherCertificationsCertDocId": ($scope.additionalCertificateFile.files) ? $scope.additionalCertificateFile.files[0].id : ''
                            }
                        }
                    }
                    saveAndCompleteWorkFlowSearchTab(obj, text, panel);
                }
            }


        }, function() {
            toaster.pop('error', "Workflow create api", "server not responding");
            $scope.loader = false;
        });
    }

    var saveAndCompleteWorkFlowSearchTab = function(obj, text, panel) {
        WorkFlow.searchWorkflowSave($cookieStore.get("searchRequestId"), obj).then(function(data) {
            WorkFlow.completeWorkflowForSearchTab($cookieStore.get("searchTaskId")).then(function(data) {
                $scope.loader = false;
                if (text == "companyEdit") {
                    $scope.companyEditSection = false;
                    $scope.companyEditNonSection = true;
                    if (document.getElementById('editLegal')) {
                        document.getElementById('editLegal').style.display = "none";
                    }
                } else if (text == "certificationTab") {
                    $scope.editCertification = false;
                    $scope.certificationNonEdit = true;
                    $scope.editCertificationIcon = true;
                } else if (text == "AddressTab") {
                    $scope.editAddressSection = false;
                    $scope.addressNonEditSection = true;
                } else if (text == "paymentTab") {
                    $scope.bankAccountsDetails = true;
                    document.getElementById('bankAccountsDetails').style.display = "block";
                    $scope.editForBankSection = false;

                } else if (text == "contactTab") {
                	
                    $scope.editContactSection = false;
                    $scope.contactSectionNew=true;
                    $scope.contactNonEditSection = true;
                }
                $cookieStore.remove("searchTaskId");
                $scope.loader = true;
                $scope.getDetailsWithStatus(panel);
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "Workflow complete api", "server not responding");
            });

        }, function() {
            toaster.pop('error', "Workflow save api", "server not responding");
            $scope.loader = false;
        });
    }

    $scope.cancelClick = function(text) {
        $scope.loader = true;
        //WorkFlow.cancelWorkflowV2($cookieStore.get("searchTaskId")).then(function(data) {
            $scope.loader = false;
            if (text == "company") {
                $scope.companyEditSection = false;
                $scope.companyEditNonSection = true;
            } else if (text == "address") {
                $scope.addressNewSection = true;
                $scope.addressHeadSection = true;
                $scope.editAddressSection = false;
                $scope.addressNonEditSection = true;
            } else if (text == "payment") {
                $scope.bankAccountsDetails = true;
                $scope.editForBankSection = false;
            } else if (text == "contact") {
                $scope.contactSectionNew = true;
                $scope.editContactSection = false;
                $scope.contactNonEditSection = true;
            }
            $cookieStore.remove("searchTaskId");

        /*}, function(data) {
            $scope.loader = false;
            toaster.pop('error', "WorkFlow cannot be cancelled", "Server not responding");
        });*/
    }


    /************ Document Upload ********/
    $scope.eventId = "";
    $scope.getCurrentIdFound = "";
    var eventIdTrack;
    var currentId;

    $scope.setFiles = function(element, files, obj) {
        var getElementId = element.id.split('_');
        var index = getElementId[1];
        console.log($scope[obj]);
        $scope.eventId = files;
        if (index == '') {
            // single file
            //$scope[obj].files = [];
            $scope.$apply(function($scope) {
                $scope[obj].files = ($scope[obj].files) ? $scope[obj].files : [];
                for (var i = 0; i < element.files.length; i++) {
                    //$scope[files].push(element.files[i]);
                    $scope[obj].files.push(element.files[i]);
                    uploadFileSend($scope[obj].files[$scope[obj].files.length - 1]);
                }
            });

        } else {

            $scope.$apply(function($scope) {
                $scope[obj][index].files = ($scope[obj][index].files) ? $scope[obj][index].files : [];
                for (var i = 0; i < element.files.length; i++) {
                    //$scope[files].push(element.files[i]);
                    $scope[obj][index].files.push(element.files[i]);
                    uploadFileSend($scope[obj][index].files[$scope[obj][index].files.length - 1]);
                }
            });

        }


    };

    function uploadFileSend(file) {
        //// TODO - REMOVE This
        //localStorage.setItem("userId", 111);///
        $scope.loader = true;
        console.log("supplierApiUrl", constants.SUPPLIER_API_URL);
        console.log("file", file);
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        $scope.preloader = true;
        $scope.fileName = file.name;
        var formData = new FormData();
        formData.append('file', file);
        formData.append('SUPPLIERID', localStorage.getItem("userId"));
        formData.append('docType', $scope.eventId);

        console.log("formData", formData)
        var req = {
            method: 'POST',
            url: constants.FILE_UPLOAD_MULTIPLE,
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined,
                'Authorization': WorkFlow.getCookieVal()
            },
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        };
        $http(req).then(function(data) {
            
            $scope.loader = false;
            toaster.pop('success', "Document Upload", "File uploaded successfully");

            file.downloadUrl = constants.FILE_DOWNLOAD + localStorage.getItem("userId") + '-' + data.data[0].fileId + '-' + data.data[0].docType;
            file.id = localStorage.getItem("userId") + '-' + data.data[0].fileId + '-' + data.data[0].docType;
        }, function() {
            $scope.loader = false;
            $scope.eventId = "";
            $scope.getCurrentIdFound = "";
            $scope.preloader = false;
            toaster.pop('error', "Document Upload", "server not responding");
        });

    }
	
    $scope.checkTaxApiValidationForSearchPage = function(supplierData, country) {
        $scope.loader = true;
        supplier.checkTaxApiValidationForSearchPage(supplierData, country).then(function(data) {
            $scope.loader = false;
            if (data.data == true) {
                $scope.legalTaxRule = true;
                //			toaster.pop('success', "Tax Validation api");
            } else {
                $scope.legalTaxRule = false;
                toaster.pop('error', "Tax Validation api fails");
            }
        }, function() {
            $scope.loader = false;
            toaster.pop('error', "Tax Validation api", "Tax Validation api fails");
        });
    }
    $scope.checkTaxApiValidationForSearchPageForOwner = function(supplierData) {
        $scope.loader = true;
        if (supplierData.ownerTaxClassifyLegalEntity) {
            angular.forEach($scope.withHoldingTypesForOwner, function(item, index) {
                if (item.name == supplierData.ownerTaxClassifyLegalEntity) {
                    $scope.taxClassifyValidationForOwner = item.id;
                }
            });
        }

        angular.forEach($scope.chooseCountries, function(value, key) {
            if (value.name == supplierData.ownerCountryLegalEntity) {
                $scope.countryNameForOwner = value.code;

            }
        });


        supplier.checkTaxApiValidationForSearchPageForOwner($scope.countryNameForOwner, supplierData).then(function(data) {
            $scope.loader = false;
            if (data.data == true) {
                $scope.legalTaxRuleOwner = true;
                //				toaster.pop('success', "Tax Validation api");
            } else {
                $scope.legalTaxRuleOwner = false;
                toaster.pop('error', "Tax Validation api fails");
            }
        }, function() {
            $scope.loader = false;
            toaster.pop('error', "Tax Validation api", "Tax Validation api fails");
        });
    }



    //Function for getting subscription id in add new section /////////////////////////////////////////////////////////////

    $scope.getSubscribersForAddNew = function(tab) {
        $scope.mainArrayForAddNewSection = [];
        supplier.getNewSubscribersForAddNew($scope.supplierIdInSearch).then(function(data) {
            $scope.getNewSubscribersForAddNew = data.data;
            angular.forEach($scope.getNewSubscribersForAddNew, function(value, key) {
                $scope.subscriberId = value.id;
                supplier.getSubscriptionDetailsForIdFromSearch(value.id).then(function(data) {
                    $scope.loader = true;
                    var getSupplierPayTermLegalForAdd = data.data.subscription.subscriptionData.paymentTermId;
                    var getCommodityPayTermLegalForAdd = data.data.subscription.subscriptionData.commodityTier1Id;

                    angular.forEach(data.data.subscriberIds, function(subId, key) {
                        supplier.getBusinessSubListNewById(subId).then(function(data) {
                            var item = {
                                "id": value.id,
                                "erpOrgName": data.erpOrgName,
                                "name": data.name,
                                "erpOrgNumber": data.erpOrgNumber,
                                "erpOrgName": data.erpOrgName,
                                "country": data.erpCountryCode,
                                "payTerm": getSupplierPayTermLegalForAdd,
                                "commodity": getCommodityPayTermLegalForAdd,
                                selected: true
                            };
                            $scope.mainArrayForAddNewSection.push(item)
                            $scope.loader = false;
                            $scope.addSubscribersFromAddTab(item, tab)

                        }, function() {
                            $scope.loader = false;
                        });
                    });

                }, function() {
                    $scope.loader = false;
                });


            });




        }, function() {
            $scope.loader = false;
            toaster.pop('error', "Tax Validation api", "Tax Validation api fails");
        });
    }




    $scope.addAddress = function() {
        $scope.addressNewSection = false;
        $scope.contactSectionNew = false;
        $scope.getSubscribersForAddNew('address');
        $scope.addressHeadSection = false;
        $scope.editAddressSection = false;
        $scope.addAddressSection = true;
        $scope.addressNonEditSection = false;
        $scope.addressBtn = false;
        $scope.AddressSubscribeSection = false;
        $scope.supplierData.multiSelectAddress='';
        $scope.supplierData.addAddressLine1 = '';
        $scope.supplierData.addAlternateName = '';
        $scope.supplierData.addAddressLine2 = '';
        $scope.supplierData.addAddressLine3 = '';
        $scope.supplierData.addAddressLine4 = '';
        $scope.supplierData.addCity = '';
        $scope.supplierData.addPostalCode = '';
        $scope.supplierData.addState = '';
        $scope.supplierData.addCountry = '';
		$scope.addressTypes.orderfulfilling = false;
		$scope.addressTypes.remittance = false;
		$scope.addressTypes.manufacturing = false;
		$scope.addressTypes.alternateShip = false;
		$scope.stateLabel = 'State';
		$scope.stateList = [];
    }
    $scope.cancelAddAddress = function() {
        $scope.addressNewSection = true;
        $scope.contactSectionNew = true;
        $scope.editAddressSection = false;
        $scope.addressBtn = true;
        $scope.addressNonEditSection = true;
        $scope.addAddressSection = false;
    }

    $scope.addContactNew = function(panel, supplierData, supplierDataContact) {
    	if($scope.contactSubscribersArray==undefined){
            toaster.pop('error', "Subscriber check ", "Please check atleast one subscriber");
            return
    	}
        panel.contactSubmitted = true;
        var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (supplierData.contactEmail && !regEx.test(supplierData.contactEmail)) {
            toaster.pop('error', "Please enter valid email");
            return;
        }

        if (supplierDataContact.$invalid) {
            toaster.pop('error', "", "Please fill all mandatory fields");
            return;
        }

        if (!supplierData.businessCodeShortForContact) {
            toaster.pop('error', "", "Please fill business phone code");
            return;
        }
        //		$scope.loader=true;
        var subscriptionArray = [];

        angular.forEach($scope.mainArrayForAddNewSection, function(item, key) {
            if (item.check) {
                subscriptionArray.push(item.id)
            }
        });

        var conObj = {
            "partyId": $scope.supplierIdInSearch,
            "subscription": {
                "subscriptionIds": subscriptionArray
            },
            "supplier": {
                "contacts": [{
                    "businessPhoneCountryId": supplierData.businessCodeShortForContact,
                    "businessPhoneNumber": supplierData.contactBusinessPhoneNo,
                    "email": supplierData.contactEmail,
                    "firstName": supplierData.contactFirstName,
                    "lastName": supplierData.contactLastName,
                    "mobilePhoneCountryId": supplierData.mobileCodeShortForContact,
                    "mobilePhoneNumber": supplierData.contactMobilePhoneNo,
                    "contactType": supplierData.addContactTypeForContact
                }]
            }
        }
        console.log(conObj);
        var text = "SUPPLIER_CONTACT_ADD";
        $scope.loader = true;
        supplier.editCreateWorkflow(text).then(function(data) {
            $scope.taskId = data.taskId;
            if (data.requestId) {
                WorkFlow.searchWorkflowSave(data.requestId, conObj).then(function(data) {
                    WorkFlow.completeWorkflowForSearchTab($scope.taskId).then(function(data) {
                        $scope.loader = false;
                        $scope.getDetailsWithStatus(panel);
                        $scope.cancelContact();
                    }, function(data) {
                        $scope.loader = false;
                        toaster.pop('error', "WorkFlow Complete Api Fails", "Server not responding");
                    });
                }, function(data) {
                    $scope.loader = false;
                    toaster.pop('error', "WorkFlow Save Api Fails", "Server not responding");
                });
            }
        }, function() {
            $scope.loader = false;
        });
    }
    $scope.showRemittanceEmailSection = function(){
        if($scope.addressTypes.orderfulfilling == true){
            $scope.remittanceEmailSection = true;
        }else{
            $scope.remittanceEmailSection = false;
        }
    }
    $scope.addAddressBtnClick = function(panel, supplierData, addressTypes) {
        if(addressTypes ==undefined){
            toaster.pop('error', "Address Type", "Please check atleast one address Type");
            return;
        }
    	if($scope.addressSubscribersArray==undefined){
            toaster.pop('error', "Subscriber check ", "Please check atleast one subscriber");
            return;
    	}
        if(!supplierData.addPostalCode || !supplierData.addCity ||!supplierData.addState){
            toaster.pop('error', "", "Please fill all mandatory fields");
            return;
        }
        if($scope.remittanceEmailSection){
            if(!supplierData.remittanceEmail){
                toaster.pop('error', "", "Please provide remittance email address");
                return;
            }
        }
        panel.addressSubmitted = true;
        //$scope.loader=true;
        if (supplierData.$invalid) {
            toaster.pop('error', "", "Please fill all mandatory fields");
            return;
        }
        
        $scope.searchAddressType = [];
        if(addressTypes.orderfulfilling == true){
            addressTypes.orderfulfilling = "ORDER_FULLFILLING";
            $scope.searchAddressType.push(addressTypes.orderfulfilling);
        }
        if(addressTypes.remittance == true){
            addressTypes.remittance = "REMITTANCE";
            $scope.searchAddressType.push(addressTypes.remittance);
        }
        if(addressTypes.manufacturing == true){
            addressTypes.manufacturing = "MANUFACTURING";
            $scope.searchAddressType.push(addressTypes.manufacturing);
        }
        if(addressTypes.alternateShip == true){
            addressTypes.alternateShip = "SHIP_FROM_ALT";
            $scope.searchAddressType.push(addressTypes.alternateShip);
        }
        var subscriptionArray = [];

        angular.forEach($scope.mainArrayForAddNewSection, function(item, key) {
            if (item.check) {
                subscriptionArray.push(item.id)
            }
        });

        var addObj = {
            "partyId": $scope.supplierIdInSearch,
            "subscription": {
                "subscriptionIds": subscriptionArray
            },
            "supplier": {
                "addresses": [{
                    "addressTypes": $scope.searchAddressType,
                    "alternateName": supplierData.addAlternateName,
                    "location": {
                        "addressLine1": supplierData.addAddressLine1,
                        "addressLine2": supplierData.addAddressLine2,
                        "addressLine3": supplierData.addAddressLine3,
                        "addressLine4": supplierData.addAddressLine4,
                        "cityName": supplierData.addCity,
                        "postalCode": supplierData.addPostalCode,
                        "stateId": supplierData.addState.id,
                        "countryId": supplierData.addCountry,
                        "stateName": supplierData.addState.subdivisionName
                    },
                    "emailForPurchaseOrders": supplierData.POemail,
                    "emailForRemittance":supplierData.remittanceEmail
                }]
            }
        }
        console.log(addObj);
        var text = "SUPPLIER_ADDRESS_ADD";
        $scope.loader = true;
        supplier.editCreateWorkflow(text).then(function(data) {
            $scope.taskId = data.taskId;
            if (data.requestId) {
                WorkFlow.searchWorkflowSave(data.requestId, addObj).then(function(data) {
                    WorkFlow.completeWorkflowForSearchTab($scope.taskId).then(function(data) {
                        $scope.loader = false;
                        $scope.getDetailsWithStatus(panel);
                        $scope.cancelAddAddress();
                        //reset
                        // supplierData.multiSelectAddress = [];
                        $scope.searchAddressType = [];
                        supplierData.addAlternateName = "";
                        supplierData.addAddressLine1 = "";
                        supplierData.addAddressLine2 = "";
                        supplierData.addAddressLine3 = "";
                        supplierData.addAddressLine4 = "";
                        supplierData.addCity = "";
                        supplierData.addPostalCode = "";
                        supplierData.addState.id = "";
                        supplierData.addCountry = "";
                        supplierData.addState.subdivisionName = "";
                        supplierData.POemail = "";
                        supplierData.remittanceEmail = "";
                    }, function(data) {
                        $scope.loader = false;
                        toaster.pop('error', "WorkFlow Complete Api Fails", "Server not responding");
                    });
                }, function(data) {
                    $scope.loader = false;
                    toaster.pop('error', "WorkFlow Save Api Fails", "Server not responding");
                });

            }
        }, function() {
            $scope.loader = false;
        });


    }
    $scope.addPaymentBtnAction = function(panel) {
        $scope.getSubscribersForAddNew('payment');
        $scope.addPaymentBtn = false;
        $scope.addPaymentSection = true;
        $scope.editForBankSection = false;
        $scope.bankHeader = false;
        $scope.bankAccountsDetails = false;
        panel.routingLabel = 'Bank Code';
        panel.routingTooltip = 'Bank Code';
        panel.accountTooltip = 'Please enter Account Number';
        panel.addresses = angular.copy($scope.addresses);
        panel.bankCreditDetails = false;
        panel.primaryAccount = false;

        panel.bankCountryCode = '';
        panel.bankCurrency = '';
        panel.bankAccountName = '';
        panel.abaRouting = '';
        panel.maskedAccountNumber = '';
        panel.bankAccountNumber = '';
        panel.remittance = '';
        panel.bankCreditName = '';
        panel.bankCreditNumber = '';
        panel.bankCreditBenName = '';
		
		panel.showForm = false;
		panel.branch_information = '';
		panel.branch_information_alt = '';
		panel.institution_name = '';
		panel.institution_name_alt = '';
		panel.POBnumber = '';
		panel.address1 = '';
		panel.town_name = '';
		panel.country_name = '';
		panel.country_subdivision = '';
		panel.zip_code = '';
		panel.failCounter = 0;


    }
    $scope.cancelPayment = function() {
        $scope.bankHeader = true;
        $scope.bankAccountsDetails = true;
        $scope.addPaymentSection = false;
        $scope.addPaymentBtn = true;
		
		$scope.panel.showForm = false;
		$scope.panel.branch_information = '';
		$scope.panel.branch_information_alt = '';
		$scope.panel.institution_name = '';
		$scope.panel.institution_name_alt = '';
		$scope.panel.POBnumber = '';
		$scope.panel.address1 = '';
		$scope.panel.town_name = '';
		$scope.panel.country_name = '';
		$scope.panel.country_subdivision = '';
		$scope.panel.zip_code = '';
    }
    
    $scope.savePaymentPayment = function(panel, addBankForm) {
		
		/*
		var alertCurrencyPrimary = false;		
		angular.forEach($scope.bankAccounts, function (val2, index2) {					
				if (panel.primaryAccount==true && val2.partyBankInfo.isPrimary==true) {
					if(panel.bankCurrency == val2.partyBankInfo.accountCurrencyCode ) {						
						alertCurrencyPrimary = true;								
					}							
				}					
		});
		if (alertCurrencyPrimary) {
			toaster.pop('error', "", "You have already selected primary bank for this currency");
			return;
		} */

		
    	if($scope.paymentSubscribersArray==undefined || $scope.paymentSubscribersArray.length <= 0){

            toaster.pop('error', "Subscriber check ", "Please check atleast one subscriber");
            return
    	}

        panel.bankSubmitted = true;
        if (addBankForm.$invalid) {
            toaster.pop('error', "", "Please fill all mandatory fields");
            return;
        }

        var assocFlag = false;
        var linkAddresses = []
        angular.forEach(panel.addresses, function(address, key) {
            if (address.assocAddress) {
                linkAddresses.push(address.entityId);
                assocFlag = true;
            }
        });

        if (assocFlag == false) {
            toaster.pop('error', "", "Please choose atleast one associate address for each bank");
            return;
        }
		
		
		
		

		

        var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (panel.remittance && !regEx.test(panel.remittance)) {
            //panel.invalidEmail = false;
            toaster.pop('error', "Please enter valid remittance email");
            return;
        }


        var idArray = $filter('filter')($scope.chooseCountries, {
            'id': panel.bankCountryCode
        });
        var countryCode = ''
        if (idArray[0].code) {
            countryCode = idArray[0].code
        }
		panel.chinaCase = false;	
		// CHINA - diffrent case
		if(idArray[0].code == 'CN' && idArray[0].currencyCode == 'CNY' ){
			
			//if(!item.branch_information_alt){							
				panel.chinaCase = true;													
			//}
		}
		
		
        supplier.AccountNumberFormat(panel.bankAccountNumber, countryCode).then(function(data) {

            if (data.data == "true") {
                panel.acFormatValidation = true;
                supplier.LocalRoutingFormat(panel.abaRouting, countryCode).then(function(data) {

                    if (data.data == "true") {
                        panel.localRoutingValidation = true;
						
						if (panel.failingCaseTrue == false || panel.failingCaseTrue == null) {
								// SWIFT call on rule engine success
								supplier.abaNumberRouting(panel.abaRouting, countryCode).then(function(data) {
									//toaster.pop('success', $scope.routingLabel+" Format Valid", $scope.uiMessage);
									// $scope.loader=false;
									if (data) {

										supplier.getBranchInfo(panel.abaRouting, countryCode).then(function(data) {
											//panel.bankName = data.national_ids[0].institution_name;
									
											/*
											
											
											panel.bankName = data.institution_name;
											panel.addressLine1 = data.address.address_lines[0];
											panel.addressLine2 = data.address.address_lines[1];
											panel.addressLine3 = data.address.address_lines[2];
											panel.addressLine4 = data.address.address_lines[3];
											panel.bankCountryCode = data.address.country_code;
											panel.bankCountryName = data.address.country_name;
											panel.bankStateName = data.address.country_subdivision;
											panel.bankCityName = data.address.town_name;
											panel.bankBranchInformation = data.branch_information;																	
											save();*/
											
													panel.failingCaseTrue = false;
													if (data.length == 0) {
															if (panel.branch_information == null || panel.institution_name == null || item.address1 == null || item.town_name == null || item.country_subdivision == null || item.country_name == null) {
																panel.showForm = true;
																toaster.pop('error', "Mandatory Fields", "Please fill all the mandatory fields");
																return;
															} else {
																panel.bankName = panel.institution_name;
																panel.addressLine1 = panel.address1;
																panel.addressLine2 = panel.address2;
																panel.addressLine3 = panel.address3;
																panel.addressLine4 = panel.address4;
																panel.bankCountryCode = panel.bankCountryCode;
																panel.bankCountryName = panel.country_name;
																panel.bankStateName = panel.country_subdivision;
																panel.bankCityName = panel.town_name;
																panel.bankBranchInformation = panel.branch_information;
																panel.bankInstitutionName = panel.institution_name;
																panel.bankpoBoxNumber = panel.POBnumber;

															}

														} else {
															panel.bankName = data.institution_name;
															panel.addressLine1 = data.address.address_lines[0];
															panel.addressLine2 = data.address.address_lines[1];
															panel.addressLine3 = data.address.address_lines[2];
															panel.addressLine4 = data.address.address_lines[3];
															panel.bankCountryCode = panel.bankCountryCode;
															panel.bankCountryName = data.address.country_name;
															panel.bankStateName = data.address.country_subdivision;
															panel.bankCityName = data.address.town_name;
															panel.bankBranchInformation = data.branch_information;
															panel.bankInstitutionName = data.institution_name;
															panel.bankpoBoxNumber = data.address.post_office_box;
															// Fill form with fields - if china
															if(panel.chinaCase && !panel.institution_name_alt ) {
																alertFlag=true;
																panel.showForm = true;
																panel.branch_information_alt =  data.branch_information;
																panel.institution_name_alt =  data.institution_name;
																panel.address1 = data.address.address_lines[0];
																panel.zip_code = data.address.post_code[0];
																panel.town_name = data.address.town_name;
																panel.POBnumber = data.address.post_office_box;
																panel.country_name = panel.bankCountryCode;
																$scope.getStateListForBankCountry(panel);																
															}
														}
														
														save();

										}, function(data) {
											$scope.loader = false;
											panel.failCounter++;
											if(panel.failCounter>=2) {
												panel.showForm = true;
												panel.failingCaseTrue = true;
												
											}
											
											if (data.httpStatusCode == 404) {
												$scope.uiMessage = data.uiMessage;
												toaster.pop('error', panel.routingLabel + " Format Valid", $scope.uiMessage);
												$scope.loader = false;
												return;
											}

											
										});
										$scope.loader = false;
									}
								}, function(data) {
									//save();
									$scope.loader = false;
									panel.failCounter++;
									if(panel.failCounter>=2) {
										panel.showForm = true;
										panel.failingCaseTrue = true;										
									}
									
									if (data.httpStatusCode == 404) {
										$scope.uiMessage = data.uiMessage;
										toaster.pop('error', panel.routingLabel + " Format Valid", $scope.uiMessage);
										
										return;
									}
								});
						} else {
							
								/*

																							
										var obj = {
												partyAccountName: value.bankAccountName,
												partyAccountNameAlt: null,
												partyBankInfo: {
													//institutionName: value.bankInstitutionName,
													bankNameAlt: value.institution_name_alt,
													branchNameAlt: value.branch_information_alt ,
													bankCountryCode: value.bankCountryCode,
													bankCountryName: value.bankCountryName,
													bankLocalRoutingNumber: value.abaRouting,
													accountNumber: value.bankAccountNumber,
													accountCurrencyId: value.bankCurrency,
													iban: value.iban,
													swift: value.swift,
													isPrimary: value.primary,
													remittanceEmailAddress: value.remittance,
													addresses: [],
													//branchInformation: value.bankBranchInformation,
													branchName: value.branch_information,
													bankAddress: {
														"countryId": value.bankCountryCode,
														"stateId": value.country_subdivision,
														"stateName": null,
														"cityName": value.town_name,
														"provinceName": value.bankStateName,
														"postalCode": value.zip_code,
														"addressLine1": value.address1,
														"addressLine2": value.address2,
														"addressLine3": value.address3,
														"addressLine4": value.address4,
														"poBoxNumber": value.POBnumber
													},
													bankName: value.institution_name
															//bankName: 'BANK OF AMERICA N.A.'
												},
												useFurtherCreditTo: value.bankCreditDetails,
												furtherCreditTo: {
													bankName: value.bankCreditName,
													accountNumber: value.bankCreditNumber,
													beneficiaryName: value.bankCreditBenName
												}
										}; */
										
										panel.addressLine1 = panel.address1;
										panel.addressLine2 = panel.address2;
										panel.addressLine3 = panel.address3;
										panel.addressLine4 = panel.address4;
										
										save();
										
					
								
							
						}



                    } else {

                        $scope.loader = false;
                        item.localRoutingValidation = false;

                        toaster.pop('error', item.routingLabel + "Format is not Valid", data.statusMessage);
                        return;
                    }

                });

            } else {
                alertFlag = true;
                $scope.loader = false;
                item.acFormatValidation = false;
                toaster.pop('error', "Account Number Format is not valid", data.statusMessage);
                return;
            }
        });

        var save = function() {
            $scope.loader = true;
            supplier.editCreateWorkflow("SUPPLIER_BANK_ADD").then(function(data) {
                $scope.loader = false;
                if (data) {
                    //data.instanceId;			  
                    //data.requestId;			  
                    //data.taskId;

                    var subscriptionArray = [];

                    angular.forEach($scope.mainArrayForAddNewSection, function(item, key) {
                        if (item.selected) {
                            subscriptionArray.push(item.id)
                        }
                    });
                    var obj = {
                        "partyId": panel.rootId,
                        "subscription": {
                            "subscriptionIds": subscriptionArray
                        },
                        "supplier": {
                            "banks": [{
                                "partyAccountName": panel.bankAccountName,
								"partyAccountNameAlt": null,
                                "furtherCreditTo": {
                                    "accountNumber": panel.bankCreditNumber,
                                    "bankName": panel.bankCreditName,
                                    "beneficiaryName": panel.bankCreditBenName
                                },
                                "partyBankInfo": {
									bankNameAlt: panel.institution_name_alt,
									branchNameAlt: panel.branch_information_alt ,
                                    "bankCountry": panel.bankCountryCode,                                    
                                    "bankLocalRoutingNumber": panel.abaRouting,
                                    "accountNumber": panel.bankAccountNumber,
                                    "accountCurrencyId": panel.bankCurrency,
                                    "isPrimary": panel.primaryAccount,
									"iban": panel.iban,
									"swift": panel.swift,
                                    "remittanceEmailAddress": panel.remittance,
                                    "addresses": linkAddresses,
									"bankName": panel.institution_name,
									//"branchInformation": panel.bankBranchInformation,
									//"institutionName": panel.bankName,
									"bankAddress":{
										"countryId": panel.bankCountryCode,
										"stateId": panel.country_subdivision,
										"stateName": panel.bankStateName,
										"cityName": panel.bankCityName,
										"provinceName": panel.bankStateName,
										"postalCode": panel.zip_code,
										"addressLine1": panel.addressLine1,
										"addressLine2": panel.addressLine2,
										"addressLine3": panel.addressLine3,
										"addressLine4": panel.addressLine4,
										"poBoxNumber": panel.POBnumber
									}
                                },
                                "useFurtherCreditTo": panel.bankCreditDetails
                            }]
                        }
                    }
					
                    if (!panel.bankCreditDetails) {
                        obj.supplier.banks[0].furtherCreditTo = null;
                    }

                    console.log(obj);

                    if (data.requestId) {
                        WorkFlow.searchWorkflowSave(data.requestId, obj).then(function(saveData) {
                            WorkFlow.completeWorkflowForSearchTab(data.taskId).then(function(cData) {
                                $scope.loader = false;
                                $scope.getDetailsWithStatus(panel);
                                $scope.cancelPayment();

                                panel.bankAccountName = "";
                                panel.bankCreditNumber = "";
                                panel.bankCreditName = "";
                                panel.bankCreditBenName = "";
                                panel.bankCountryCode = "";
                                panel.bankName = "";
                                panel.abaRouting = "";
                                panel.bankAccountNumber = "";
                                panel.bankCurrency = "";
                                panel.remittance = "";
								panel.showForm = false;
								panel.branch_information = '';
								panel.branch_information_alt = '';
								panel.institution_name = '';
								panel.institution_name_alt = '';
								panel.POBnumber = '';
								panel.address1 = '';
								panel.town_name = '';
								panel.country_name = '';
								panel.country_subdivision = '';
								panel.zip_code = '';
															

                            }, function(data) {
                                $scope.loader = false;
                                toaster.pop('error', "WorkFlow Complete Api Fails", "Server not responding");
                            });
                        }, function(data) {
                            $scope.loader = false;
                            toaster.pop('error', "WorkFlow Save Api Fails", "Server not responding");
                        });
                    }

                }
            }, function() {
                $scope.loader = false;
            });
        }


    }
    $scope.addNewContactClick = function() {
        $scope.getSubscribersForAddNew('contact');
        $scope.contactSectionNew = false;
        $scope.addNewContact = false;
        $scope.addContactSection = true;
        $scope.editContactSection = false;
        $scope.contactNonEditSection = false;
        $scope.supplierData.addContactTypeForContact = '';
        $scope.supplierData.contactFirstName = '';
        $scope.supplierData.contactLastName = '';
        $scope.supplierData.contactEmail = '';
        $scope.supplierData.contactBusinessPhoneNo = '';
        $scope.supplierData.contactMobilePhoneNo = '';
        $scope.supplierData.mobileCodeShortForContact='';
        $scope.supplierData.mobileCodeForContact='';
        $scope.supplierData.businessCodeShortForContact='';
        $scope.supplierData.businessCodeForContact='';
    }

    $scope.cancelContact = function() {
        $scope.contactNonEditSection = true;
        $scope.addContactSection = false;
        $scope.addNewContact = true;
        $scope.contactSectionNew = true;
    }
    $scope.changeCommodityBtnClick = function() {
        $scope.changeCommoditySection = true;
        $scope.commodityNonEditSection = false;
        $scope.changeCommodity = false;
        supplier.getCommoditiesFamilyList().then(function(data) {
            $scope.commoditiesFamilyList = data;
        }, function() {
            $scope.loader = false;
            toaster.pop('error', "Commodities list", "server not responding");
        });
        $scope.onCommodityFamilyChangeCode = function(id) {
            $scope.loader = true;
            if (id == undefined) {
                $rootScope.commodityList = [];
                $rootScope.commoditySubList = [];
                $scope.loader = false;
                return;
            } else {
                $scope.supplierInfo.commodityFamily = id;
                $scope.getCommoditySubList(id);
            }
        }
        $scope.loadNextCommodity = function(level, id) {
            $scope.loader = true;
            if (id == undefined) {
                $scope[level] = [];
                $scope.loader = false;
                return;
            } else {
                supplier.getCommoditiesSubList(id).then(function(data) {
                    if (data.length <= 0) {
                        $scope.showCommodity = false;
                        //$scope.showSubCommodity =false;
                    } else {
                        $scope.showSubCommodity = true;
                        $scope[level] = data;
                        $scope.loader = false;
                    }
                }, function() {
                    $scope.loader = false;
                });
            }
        }
        $scope.getCommoditySubList = function(id) {
            $scope.loader = true;
            if (id == undefined) {
                $rootScope.commoditySubList = [];
                $rootScope.commodityList = [];
                $scope.supplierInfo.commodity = '';
                $scope.loader = false;
                return;
            } else {
                $rootScope.commoditySubList = [];
                $scope.supplierInfo.commoditySubList = "";
                supplier.getCommoditiesSubList(id).then(function(data) {
                    $rootScope.commoditySubList = data;
                    if ($rootScope.commoditySubList.length <= 0) {
                        $scope.showSubCommodity = false;
                    } else {
                        $scope.showSubCommodity = true;
                    }
                    $scope.loader = false;
                }, function() {
                    $scope.loader = false;
                    toaster.pop('error', "Commodities sub list", "server not responding");
                });
            }
        }
        $scope.getCommoditiesList = function(id) {
                $scope.loader = true;
                if (id == undefined) {
                    $rootScope.commodityList = [];
                    $rootScope.commoditySubList = [];
                    $scope.supplierInfo.commodity = '';
                    $scope.loader = false;
                    return;
                } else {
                    supplier.getCommoditiesSubList(id).then(function(data) {
                        $scope.loader = false;
                        $rootScope.commodityList = data;
                        if ($rootScope.commodityList.length <= 0) {
                            $scope.showCommodity = false;
                        } else {
                            $scope.showCommodity = true;
                        }
                    }, function() {
                        $scope.loader = false;
                        toaster.pop('error', "commodity list", "server not responding");
                    });
                }
            }
            //business level
        supplier.getBusinessList1().then(function(data) {
            $scope.businessList1 = data;
        }, function() {
            $scope.loader = false;
            toaster.pop('error', "Business Root list", "server not responding");
        });
        $scope.onbusinessList1ChangeCode = function(id) {
            $scope.loader = true;
            if (id == undefined) {
                $scope.loader = false;
                return;
            } else {
                $scope.getBusinessList2(id);
            }
        }
        $scope.getBusinessList2 = function(id) {
            $scope.loader = true;
            if (id == undefined) {
                $rootScope.businessList2 = [];
                $rootScope.businessList3 = [];
                $rootScope.businessTableList = [];
                $scope.loader = false;
                return;
            } else {
                supplier.getBusinessSubList(id).then(function(data) {
                    $rootScope.businessList2 = data;
                    $scope.loader = false;
                }, function() {
                    $scope.loader = false;
                    toaster.pop('error', "Business sub list", "server not responding");
                });
            }
        }
        $scope.getBusinessList3 = function(id) {
                $scope.loader = true;
                if (id == undefined) {
                    $rootScope.businessList3 = [];
                    $rootScope.businessTableList = [];
                    $scope.loader = false;
                    return;
                } else {
                    supplier.getBusinessSubList(id).then(function(data) {
                        $rootScope.businessList3 = data;
                        $scope.loader = false;
                    }, function() {
                        $scope.loader = false;
                        toaster.pop('error', "Business sub list", "server not responding");
                    });
                }
            }
            //$rootScope.businessTableList=[];
        $scope.getBusinessList4 = function(id) {
            $scope.loader = true;
            if (id == undefined) {
                $rootScope.businessTableList = [];
                $scope.loader = false;
                return;
            } else {
                $rootScope.businessTableList = [];
                supplier.getBusinessSubListNew(id).then(function(data) {
                    $rootScope.businessTableList = data;
                    $scope.loader = false;
                }, function() {
                    $scope.loader = false;
                    toaster.pop('error', "Business sub list", "server not responding");
                });
            }
        }

        $scope.loadNextLevels = function(level, id) {
            $scope.loader = true;
            if (id == undefined) {
                $scope[level] = [];
                $scope.supplierInfo.businessLevel3 = '';
                $scope.loader = false;
                return;
            } else {
                supplier.getBusinessSubList(id).then(function(data) {
                    $scope[level] = data;
                    $scope.loader = false;
                }, function() {
                    $scope.loader = false;
                    toaster.pop('error', "Business sub list", "server not responding");
                });
            }
        }
        $scope.select = function(item) {
            $scope.erpId = [];
            angular.forEach($rootScope.businessTableList, function(item, key) {
                item.selected = false
            })
            item.selected = true;
            $scope.erpId.push(item.id);
        }
    }
    $scope.showPayTermBtnClick = function() {
        $scope.showPayterms = true;
        $scope.payTermBtn = false;
        $scope.payTermSectionNonEdit = false;
        supplier.getDefaultPaymentTerms().then(function(data) {
            $scope.defaultPaymentTermsData = data
        });
    }
    $scope.doPaymentTermsSearch = function(keyWord) {
        $scope.poPaymentTermsSearchResult = false;
        supplier.getPaymentTerms(keyWord).then(function(data) {
            $scope.paymentTermsData = data;
            $rootScope.paymentData = data;
            $scope.loader_poSearch = false;
            if ($scope.paymentTermsData.length > 0) {
                $scope.poPaymentTermsSearchResult = true;
            } else {
                $scope.poPaymentTermsSearchResult = false;


            }
        }, function() {

        });
    }


    //payterm businessLvels 

    //business level
    supplier.getBusinessList1().then(function(data) {
        $scope.businessList1Payterm = data;
    }, function() {
        $scope.loader = false;
        toaster.pop('error', "Business Root list", "server not responding");
    });
    $scope.onbusinessList1ChangeCodePayTerm = function(id) {
        $scope.loader = true;
        if (id == undefined) {
            $scope.loader = false;
            return;
        } else {
            $scope.getBusinessList2PayTerm(id);
        }
    }
    $scope.getBusinessList2PayTerm = function(id) {
        $scope.loader = true;
        if (id == undefined) {
            $rootScope.businessList2 = [];
            $rootScope.businessList3 = [];
            $rootScope.businessTableList = [];
            $scope.loader = false;
            return;
        } else {
            supplier.getBusinessSubList(id).then(function(data) {
                $rootScope.businessList2PayTerm = data;
                $scope.loader = false;
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "Business sub list", "server not responding");
            });
        }
    }
    $scope.getBusinessList3PayTerm = function(id) {
            $scope.loader = true;
            if (id == undefined) {
                $rootScope.businessList3 = [];
                $rootScope.businessTableList = [];
                $scope.loader = false;
                return;
            } else {
                supplier.getBusinessSubList(id).then(function(data) {
                    $rootScope.businessList3PayTerm = data;
                    $scope.loader = false;
                }, function() {
                    $scope.loader = false;
                    toaster.pop('error', "Business sub list", "server not responding");
                });
            }
        }
        //$rootScope.businessTableList=[];
    $scope.getBusinessList4PayTerm = function(id) {
        $scope.loader = true;
        if (id == undefined) {
            $rootScope.businessTableListPayTerm = [];
            $scope.loader = false;
            return;
        } else {
            $rootScope.businessTableList = [];
            supplier.getBusinessSubListNew(id).then(function(data) {
                $rootScope.businessTableListPayTerm = data;
                $scope.loader = false;
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "Business sub list", "server not responding");
            });
        }
    }

    $scope.loadNextLevels = function(level, id) {
        $scope.loader = true;
        if (id == undefined) {
            $scope[level] = [];
            $scope.supplierInfo.businessLevel3 = '';
            $scope.loader = false;
            return;
        } else {
            supplier.getBusinessSubList(id).then(function(data) {
                $scope[level] = data;
                $scope.loader = false;
            }, function() {
                $scope.loader = false;
                toaster.pop('error', "Business sub list", "server not responding");
            });
        }
    }
    $scope.selectPayTerm = function(item) {
        $scope.erpId = [];
        angular.forEach($rootScope.businessTableList, function(item, key) {
            item.selected = false
        })
        item.selected = true;
        $scope.erpId.push(item.id);
    }
    $scope.clickCancelPayTerm = function() {
        $scope.payTermSectionNonEdit = true;
        $scope.payTermBtn = true;
        $scope.showPayterms = false;
    }

    $scope.clickSavePayTerm = function(supplierData) {

    }

    $scope.clickCancelCommodityBtn = function() {
        $scope.changeCommoditySection = false;
        $scope.changeCommodity = true;
        $scope.commodityNonEditSection = true;
    }
    $scope.clickSaveCommodityBtn = function(supplierData) {

    }

    $scope.dependantTaxAuthorityForVatSection = function(country) {
        $scope.loader = true;
        supplier.taxAuthority(country).then(function(data) {
            $scope.loader = false;
            $scope.taxAuthority = data;
        }, function(data) {
            $scope.loader = false;
            toaster.pop('error', "Tax Authority Api Server Not Responding");
        });
    }

    $scope.checkVatTaxApiForVatSection = function(supplierData) {
        supplier.checkVatTaxApiValidationForSearch(supplierData).then(function(data) {
            $scope.loader = false;
            if (data.data == "true") {
                $scope.checkVatTaxApiValidation = true;
                //    			$scope.valtlist.push({countryId:supplierData.vatCountryCompanyInfo,taxAuthorityId:supplierData.vatTaxAuthorityCompanyInfo,documentId:'',taxNumber:supplierData.vatTaxIdCompanyInfo})
                toaster.pop('success', "Vat Tax Validation", "Tax ID is  valid")
            } else {
                $scope.loader = false;
                $scope.checkVatTaxApiValidation = false;
                toaster.pop('error', "Vat Tax Validation", "Tax ID is not valid or missing")
            }

        }, function(data) {
            $scope.loader = false;
            toaster.pop('error', "Vat Tax Validation", " Vat Tax ID API not responding")
        });
    }
    $scope.addmoreVatBtn = function(supplierData) {
        if (supplierData.vatCountryCompanyInfo == undefined || supplierData.vatCountryCompanyInfo == null && supplierData.vatTaxAuthorityCompanyInfo == undefined || supplierData.vatTaxAuthorityCompanyInfo == null && supplierData.vatTaxIdCompanyInfo == undefined || supplierData.vatTaxIdCompanyInfo == null ||supplierData.vatCountryCompanyInfo=="") {
            toaster.pop('error', "Vat Details Missing", "Please fill tax information");
            return;
        }
        else{
            supplier.checkVatTaxApiValidationForSearch(supplierData).then(function(data) {
                $scope.loader = false;
                if (data.data == "true") {
                    $scope.checkVatTaxApiValidation = true;
                    if ($scope.checkVatTaxApiValidation == true) {
                        $scope.valtlist.push({
                        	countryCode: supplierData.vatCountryCompanyInfo,
                            taxAuthority: supplierData.vatTaxAuthorityCompanyInfo,
                            docId: ($scope.vatDocFile.files) ? $scope.vatDocFile.files[0].id : '',
                            taxRegistrationNumber: supplierData.vatTaxIdCompanyInfo,
                            name:($scope.vatDocFile.files) ? $scope.vatDocFile.files[0].name : '',
                        })
                        $scope.supplierData.vatCountryCompanyInfo = "";
                        $scope.supplierData.vatTaxAuthorityCompanyInfo = "";
                        $scope.supplierData.vatTaxIdCompanyInfo = "";
                        $scope.vatDocFile = {};
                    }
                } else {
                    $scope.loader = false;
                    $scope.checkVatTaxApiValidation = false;
                    toaster.pop('error', "Vat Tax Validation Fails", " Vat Tax  API is giving bad response")
                }
            }, function(data) {
                $scope.loader = false;
                toaster.pop('error', "Vat Tax Validation", " Vat Tax ID API not responding")
            });
        }
        
        


    }
    
    $scope.editVatList = function() {

        var index = null;
        var flag = 0;
        angular.forEach($scope.valtlist, function(value, key) {
            if (value.check) {
                index = key;
                flag++;
            }
        });
        if (flag == 0 || flag > 1) {
            toaster.pop('error', "Vat List", "Please choose one vat list info");
            return;
        }
        
        $scope.supplierData.vatCountryCompanyInfo = $scope.valtlist[index].countryCode;
        if ($scope.supplierData.vatCountryCompanyInfo) {
        	$scope.dependantTaxAuthorityForVatSection($scope.supplierData.vatCountryCompanyInfo);
        }

        $scope.supplierData.vatTaxAuthorityCompanyInfo = parseInt($scope.valtlist[index].taxAuthority);
        $scope.supplierData.vatTaxIdCompanyInfo = $scope.valtlist[index].taxRegistrationNumber;
//        if ($scope.valtlist[index].docId != null || $scope.valtlist[index].docId != undefined) {
//        	($scope.vatDocFile.files) ? $scope.vatDocFile.files[0].name = $scope.valtlist[index].docId;
//        } 
        $scope.valtlist.splice(index, 1);

    }
    var j;
    $scope.deleteTaxRow = function() {
        var no = 0;
        $scope.noSelectedItemsCross = "";

        j = $scope.crossBorderList.length;
        angular.forEach($scope.crossBorderList, function(item, index) {
            if (item.check1 == true) {
                while (j--) {
                    if ($scope.crossBorderList[j].check1 == true) {
                        $scope.crossBorderList.splice(j, 1);
                        no++;
                        toaster.pop('success', "Tax Row Deleted", "Row has been deleted successfully ");
                    }
                    $scope.noSelectedItemsCross = no;
                }
            }


        });
        if ($scope.noSelectedItemsCross.length == 0) {
            toaster.pop('error', "Cross Order List", "Please choose atleat one row");
            return
        }
    }
    
    $scope.editTaxRow = function() {
        var editTaxListRows = $scope.crossBorderList;
        var index = null;
        var flag = 0;
        angular.forEach($scope.crossBorderList, function(value, key) {
            if (value.check1) {
                index = key;
                flag++;
            }
        });
        if (flag == 0 || flag > 1) {
            toaster.pop('error', "Tax List", "Please choose one tax list info");
            return;
        }
        
        $scope.supplierData.crossCountryCompanyInfo = $scope.crossBorderList[index].countryCode;
        $scope.supplierData.crossTaxRegNo = $scope.crossBorderList[index].taxRegistrationNumber;
        $scope.supplierData.types = $scope.crossBorderList[index].providedProductId;
//        if ($scope.crossBorderList[index].documentId != "" || $scope.crossBorderList[index].documentId != undefined || $scope.crossBorderList[index].exemptDocumentId != '' || $scope.crossBorderList[index].exemptDocumentId != undefined || $scope.crossBorderList[index].w8DocId != '' || $scope.crossBorderList[index].w8DocId != undefined || $scope.crossBorderList[index].w8BenDocId != '' || $scope.crossBorderList[index].w8BenDocId != undefined || $scope.crossBorderList[index].form8233DocId != '' || $scope.crossBorderList[index].form8233DocId != undefined) {
//            $scope.fileDownload_CrossDownload = true;
//            $scope.TaxRegFileCross.files={};
//            $scope.TaxRegFileCross.files[0].name= $scope.crossBorderList[index].documentId;
//        } else {
//            $scope.fileDownload_CrossDownload = false;
//        }

        $scope.crossBorderList.splice(index, 1);
    }
    
    $scope.deletRow = function() {
        var no = 0;
        $scope.noSelectedItems = "";

        $scope.index = [];
        i = $scope.valtlist.length;
        angular.forEach($scope.valtlist, function(item, index) {
            if (item.check == true) {
                while (i--) {
                    console.log($scope.valtlist[i].check);
                    if ($scope.valtlist[i].check == true) {
                        no++;
                        $scope.valtlist.splice(i, 1);
                    }
                    $scope.noSelectedItems = no;
                }
                toaster.pop('success', "Vat List", "Row has been deleted successfully  ");
            }



        });
        if ($scope.noSelectedItems.length == 0) {
            toaster.pop('error', "Vat List", "Please choose atleat one row");
            return
        }

    }
    

    $scope.crossAddTaxBtn = function(supplierData) {
            if (supplierData.crossCountryCompanyInfo == undefined || supplierData.crossCountryCompanyInfo == "" || $scope.supplierData.crossTaxRegNo == undefined || $scope.supplierData.crossTaxRegNo == "") {
                toaster.pop('error', "Cross Border Details Missing", "Please fill all fields");
                return
            }

            $scope.crossBorderList.push({
                countryCode: supplierData.crossCountryCompanyInfo,
                providedProductId: supplierData.types,
                taxRegistrationNumber: $scope.supplierData.crossTaxRegNo,
                documentId: ($scope.TaxRegFileCross.files) ? $scope.TaxRegFileCross.files[0].id : '',
                w8DocId: '',
                w8BenDocId: '',
                form8233DocId: '',
                exemptFromWithholdingTax: $scope.supplierData.withHoldingCrossTax,
                exemptDocumentId: ($scope.TaxExemptFile.files) ? $scope.TaxExemptFile.files[0].id : '',
                name: ($scope.TaxRegFileCross.files) ? $scope.TaxRegFileCross.files[0].name : ''
            })
            $scope.supplierData.crossCountryCompanyInfo = '';
            $scope.supplierData.crossTaxRegNo = '';
            $scope.supplierData.types = '';
            $scope.TaxRegFileCross = {};
        }
        //////////////////////PROVIDING////////////////////////////
    supplier.getGoodTypes().then(function(data) {
        $scope.mainGoodTypesList = data;
        $scope.supplierInfo.types = [];
        $scope.getGoodTypesNew = [];
        $scope.getGoodTypesRestored = data;
        angular.forEach($scope.getGoodTypesRestored, function(item, index) {
            $scope.getGoodTypesNew.push(item.name);
            $scope.getGoodTypes = $scope.getGoodTypesNew;

        });

    }, function(data) {
        $scope.loader = false;
        toaster.pop('error', "Good Types Api Server Not Responding");
    });



});


searchController.resolve = {
    roles: function(Auth, $q, $rootScope) {
        var deferred = $q.defer();
        Auth.getRoles().then(function(roles) {
            $rootScope.roleActions = roles;
            deferred.resolve(roles);
        }, function(data) {
            $rootScope.roleActions = false;
            deferred.resolve({});
        });
        return deferred.promise;
    }
}