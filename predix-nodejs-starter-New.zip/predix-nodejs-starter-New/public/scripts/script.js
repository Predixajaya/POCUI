// Code goes here

$(document).ready(function(){
  var table = $('#pamentdataTable').DataTable();
  
  $('#btn-export').on('click', function(){
      $('<table>').append(table.$('tr').clone()).table2excel({
          exclude: ".excludeThisClass",
          name: "Worksheet Name",
          filename: "Payment.xls" //do not include extension
      });
  });      
})
